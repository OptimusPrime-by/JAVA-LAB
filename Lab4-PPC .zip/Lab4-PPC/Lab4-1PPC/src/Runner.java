import java.awt.event.ActionEvent; //события
import java.awt.event.ActionListener; // обработчик событий

import javax.swing.JButton; //кнопка
import javax.swing.JFrame; //создает пустое окно с заголовком title. Контейнер
import javax.swing.JLabel; //отображение информации, картинки и тд.
import javax.swing.JOptionPane; // диалоговое окно
import javax.swing.JTextField; // поле ввода

class MyForm extends JFrame {
    public MyForm() {
        super("Первое Swing-приложение"); // Обращение к конструктору. Установка имени приложения.
        setBounds(100, 50, 380, 250); // Указание положения в пространстве и размера
        setLayout(null); // откл. авто размещения
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Загрузка операции закрытия
        JLabel firstOperandLabel = new JLabel("Первый операнд:"); // текст
        firstOperandLabel.setBounds(10, 10, 350, 30);
        add(firstOperandLabel);
        JTextField firstOperandTextField = new JTextField(); // поле ввода
        firstOperandTextField.setBounds(10, 50, 350, 30);
        add(firstOperandTextField);
        JLabel secondOperandLabel = new JLabel("Второй операнд:");
        secondOperandLabel.setBounds(10, 90, 350, 30);
        add(secondOperandLabel);
        JTextField secondOperandTextField = new JTextField();
        secondOperandTextField.setBounds(10, 130, 350, 30);
        add(secondOperandTextField);
        JButton calculateButton = new JButton("Вычислить сумму"); // кнопка
        calculateButton.setBounds(60, 170, 250, 30);
        calculateButton.addActionListener( //нажатие кнопки
                new CalculateButtonHandler(
                        firstOperandTextField,
                        secondOperandTextField
                )
        );
        add(calculateButton);
        validate(); // проверка создания контейнера
        setVisible(true); // сделать окно видимым
    }
}

class CalculateButtonHandler implements ActionListener {
    private JTextField f1, f2;
    public CalculateButtonHandler(JTextField f1, JTextField f2) {
        this.f1 = f1;
        this.f2 = f2;
    }
    @Override // проверка переопределения метода
    public void actionPerformed(ActionEvent event) {
        try {
            Double a = Double.parseDouble(f1.getText());
            Double b = Double.parseDouble(f2.getText());
            Double c = a + b;
            String result = "Сумма чисел равна " + c;
            JOptionPane.showMessageDialog(null, result);
        } catch(NumberFormatException exception) {
            JOptionPane.showMessageDialog(null, "Неверное число");
        }
    }
}

public class Runner {
    public static void main(String[] args) {
        new MyForm();
    }
}