import java.awt.*;
import java.awt.event.ActionEvent; //события
import java.awt.event.ActionListener; // обработчик событий

import javax.swing.JButton; //кнопка
import javax.swing.JFrame; //создает пустое окно с заголовком title. Контейнер
import javax.swing.JLabel; //отображение информации, картинки и тд.
import javax.swing.JOptionPane; // диалоговое окно
import javax.swing.JTextField; // поле ввода
import javax.swing.JComboBox;
import javax.swing.BoxLayout;
import javax.swing.JPanel;


class Task2 extends JFrame{
    public Task2() {
        super("Задание 2");
        setBounds(700, 350, 380, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel PositionLabel = new JLabel("Введите положение:");
        PositionLabel.setBounds(130, 10, 200, 30);
        add(PositionLabel);

        JLabel XLabel = new JLabel("x:");
        XLabel.setBounds(45, 50, 15, 30);
        add(XLabel);

        JTextField XText = new JTextField();
        XText.setBounds(60, 50, 100, 30);
        add(XText);

        JLabel YLabel = new JLabel("y:");
        YLabel.setBounds(225, 50, 15, 30);
        add(YLabel);

        JTextField YText = new JTextField();
        YText.setBounds(240, 50, 100, 30);
        add(YText);

        JLabel SizeLabel = new JLabel("Введите размер:");
        SizeLabel.setBounds(145, 90, 200, 30);
        add(SizeLabel);

        JLabel WidthLabel = new JLabel("width:");
        WidthLabel.setBounds(20, 130, 40, 30);
        add(WidthLabel);

        JTextField WidthText = new JTextField();
        WidthText.setBounds(60, 130, 100, 30);
        add(WidthText);

        JLabel HeightLabel = new JLabel("height:");
        HeightLabel.setBounds(198, 130, 40, 30);
        add(HeightLabel);

        JTextField HeightText = new JTextField();
        HeightText.setBounds(240, 130, 100, 30);
        add(HeightText);

        JLabel NumbersLabel = new JLabel("Введите колличество:");
        NumbersLabel.setBounds(125, 170, 200, 30);
        add(NumbersLabel);

        JLabel ButtonsLabel = new JLabel("кнопок:");
        ButtonsLabel.setBounds(10, 210, 50, 30);
        add(ButtonsLabel);

        JTextField ButtonsText = new JTextField();
        ButtonsText.setBounds(60, 210, 100, 30);
        add(ButtonsText);

        JLabel LabelsLabel = new JLabel("меток:");
        LabelsLabel.setBounds(200, 210, 40, 30);
        add(LabelsLabel);

        JTextField LabelsText = new JTextField();
        LabelsText.setBounds(240, 210, 100, 30);
        add(LabelsText);

        JLabel ManagerLabel = new JLabel("Выберите менеджер размещения:");
        ManagerLabel.setBounds(100, 250, 200, 30);
        add(ManagerLabel);

        String[] managers = {"BoxLayout", "FlowLayout", "GridLayout"};
        JComboBox ManagerComboBox = new JComboBox(managers);
        ManagerComboBox.setBounds(150, 290, 100, 30);
        add(ManagerComboBox);

        JButton CreateChildButton = new JButton("Создать дочернее окно.");
        CreateChildButton.setBounds(60, 330, 250, 30);
        CreateChildButton.addActionListener(new CreateChildButtonHandler(XText, YText, WidthText, HeightText, ButtonsText, LabelsText, ManagerComboBox));
        add(CreateChildButton);
        validate();
        setVisible(true);
    }
}
class ChildTask2 extends JFrame {
    public ChildTask2(int x, int y, int width, int height, int buttons, int labels, int indexManagers) {
        super("Дочернее окно");
        setBounds(x, y, width, height);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JButton[] buttonsArray = new JButton[buttons];
        for (int i = 0; i < buttons; i++){
            buttonsArray[i] = new JButton(i+1 + "");
        }
        JLabel[] labelsArray = new JLabel[labels];
        for (int i = 0; i < labels; i++){
            labelsArray[i] = new JLabel(i+1 + "");
        }
        JPanel panel = new JPanel();
        if(indexManagers == 0){
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // сверху вниз
        }
        if(indexManagers == 1){
            panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        }
        if(indexManagers == 2) {
            panel.setLayout(new GridLayout(0, buttons));
        }
        for (int i = 0; i < buttons; i++){
            panel.add(buttonsArray[i]);
        }
        for (int i = 0; i < labels; i++) {
            panel.add(labelsArray[i]);
        }
        add(panel);
        validate();
        setVisible(true);

    }
}

class CreateChildButtonHandler implements ActionListener {
    private JTextField Text1, Text2, Text3, Text4, Text5, Text6;
    private JComboBox Manager;
    public CreateChildButtonHandler(JTextField Text1,JTextField Text2,JTextField Text3,JTextField Text4,JTextField Text5,JTextField Text6,JComboBox Manager){
        this.Text1 = Text1;
        this.Text2 = Text2;
        this.Text3 = Text3;
        this.Text4 = Text4;
        this.Text5 = Text5;
        this.Text6 = Text6;
        this.Manager = Manager;
    }
    @Override
    public void actionPerformed(ActionEvent event) {
        try {
            int NumberX = Integer.parseInt(Text1.getText());
            int NumberY = Integer.parseInt(Text2.getText());
            int NumberWidth = Integer.parseInt(Text3.getText());
            int NumberHeight = Integer.parseInt(Text4.getText());
            int NumberButtons = Integer.parseInt(Text5.getText());
            int NumberLabels = Integer.parseInt(Text6.getText());
            int IndexManager = Manager.getSelectedIndex(); // 0-BoxLayout, 1-FlowLayout, 2-GridLayout
            new ChildTask2(NumberX, NumberY, NumberWidth, NumberHeight, NumberButtons, NumberLabels, IndexManager);
        } catch(NumberFormatException exception) {
            JOptionPane.showMessageDialog( null, "Неверный ввод чисел");
        }

    }
}

public class Starting {
    public static void main(String[] args) {
        new Task2();
    }
}