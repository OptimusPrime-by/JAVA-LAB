import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JFrame;

class ChildTask4 extends JFrame{
    public ChildTask4(int A, int B, int C, int D, int X1, int X2){
        super("График");
        setBounds(700, 350, 380, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        add(new Graphic(A, B, C, D, X1, X2));
        validate();
        setVisible(true);
    }
}
class Graphic extends Canvas {
    private int A, B, C, D, X1, X2;
    public Graphic(int A, int B, int C, int D, int X1, int X2){
        this.A = A;
        this.B = B;
        this.C = C;
        this.D = D;
        this.X1 = X1;
        this.X2 = X2;
    }
    public double Function(double X){
        return (A*Math.cos(B*X) + Math.pow(C,1-D*X*X));
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Rectangle r = g.getClipBounds();
        g.setColor(Color.LIGHT_GRAY);
        for(int i = r.width/2; i < r.width; i+=30){ // цикл от центра до правого края
            g.drawLine(i, 0, i, r.height);
        }
        for(int i = r.width/2; i > 0; i-=30){ // цикл от центра до леваого края
            g.drawLine(i, 0, i, r.height);
        }
        for(int j = r.height/2; j < r.height; j+=30){ // цикл от центра до верхнего края
            g.drawLine(0, j, r.width, j);
        }
        for(int j = r.height/2; j > 0 ; j-=30){ // цикл от центра до леваого края
            g.drawLine(0, j, r.width, j);
        }
        g.setColor(Color.BLACK);
        g.drawLine(r.width/2, 0, r.width/2, r.height); //оси
        g.drawLine(0, r.height/2, r.width, r.height/2);
        g.setColor(new Color(0, 48, 209));
        int realX, y, y1, x = 0;
        double function;
        realX = x + X1; // так, как слева от оси OX минус, то отнимаем от текущей точки центральную точку
        double rad = realX / 30.0;   // переводим текущую коориднату в радианы, 30 пикселей по ширине == 1 радиану
        function = Function(rad);
        y = 2*r.height / 3 - (int) (function*90); // переводим значение функции в координату нашей системы
        for(x = 0; x < Math.abs(X2 - X1)-1; x++) {
            realX = (x + 1) + X1 ;
            rad = realX / 30.0;
            function = Function(rad);
            y1 = 2*r.height / 3 - (int) (function*90);
            g.drawLine(x + (r.width / 2 + X1), y, x + 1 + (r.width / 2 + X1), y1);
            y = y1;
        }
    }
}
