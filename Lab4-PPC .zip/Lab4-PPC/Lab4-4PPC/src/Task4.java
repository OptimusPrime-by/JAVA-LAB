import java.awt.event.ActionEvent; //события
import java.awt.event.ActionListener; // обработчик событий

import javax.swing.*;

public class Task4 extends JFrame{
    public Task4() {
        super("Задание 4");
        setBounds(700, 350, 380, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel ParamsLabel = new JLabel("Введите числа:");
        ParamsLabel.setBounds(10, 10, 200, 30);
        add(ParamsLabel);

        JLabel ALabel = new JLabel("a:");
        ALabel.setBounds(45, 50, 15, 30);
        add(ALabel);

        JTextField AText = new JTextField();
        AText.setBounds(60, 50, 100, 30);
        add(AText);

        JLabel BLabel = new JLabel("b:");
        BLabel.setBounds(225, 50, 15, 30);
        add(BLabel);

        JTextField BText = new JTextField();
        BText.setBounds(240, 50, 100, 30);
        add(BText);

        JLabel CLabel = new JLabel("c:");
        CLabel.setBounds(45, 90, 15, 30);
        add(CLabel);

        JTextField CText = new JTextField();
        CText.setBounds(60, 90, 100, 30);
        add(CText);

        JLabel DLabel = new JLabel("d:");
        DLabel.setBounds(225, 90, 15, 30);
        add(DLabel);

        JTextField DText = new JTextField();
        DText.setBounds(240, 90, 100, 30);
        add(DText);

        JLabel IntervalLabel = new JLabel("Введите интервал:");
        IntervalLabel.setBounds(10, 130, 200, 30);
        add(IntervalLabel);

        JLabel X1Label = new JLabel("x1:");
        X1Label.setBounds(40, 170, 20, 30);
        add(X1Label);

        JTextField X1Text = new JTextField();
        X1Text.setBounds(60, 170, 100, 30);
        add(X1Text);

        JLabel X2Label = new JLabel("x2:");
        X2Label.setBounds(220, 170, 20, 30);
        add(X2Label);

        JTextField X2Text = new JTextField();
        X2Text.setBounds(240, 170, 100, 30);
        add(X2Text);

        JButton CreateGraphButton = new JButton("Построить график.");
        CreateGraphButton.setBounds(60, 330, 250, 30);
        CreateGraphButton.addActionListener(new CreateGraphButtonHandler(AText, BText, CText, DText, X1Text, X2Text));
        add(CreateGraphButton);
        validate();
        setVisible(true);
    }
}

class CreateGraphButtonHandler implements ActionListener {
    private JTextField Text1, Text2, Text3, Text4, Text5, Text6;
    public CreateGraphButtonHandler(JTextField Text1,JTextField Text2,JTextField Text3,JTextField Text4,JTextField Text5,JTextField Text6){
        this.Text1 = Text1;
        this.Text2 = Text2;
        this.Text3 = Text3;
        this.Text4 = Text4;
        this.Text5 = Text5;
        this.Text6 = Text6;
    }
    @Override
    public void actionPerformed(ActionEvent event) {
        try {
            int NumberA = Integer.parseInt(Text1.getText());
            int NumberB = Integer.parseInt(Text2.getText());
            int NumberC = Integer.parseInt(Text3.getText());
            int NumberD = Integer.parseInt(Text4.getText());
            int NumberX1 = Integer.parseInt(Text5.getText());
            int NumberX2 = Integer.parseInt(Text6.getText());
            if(NumberX1 < NumberX2) new ChildTask4(NumberA, NumberB, NumberC, NumberD, NumberX1, NumberX2);
            else JOptionPane.showMessageDialog( null, "Неверно задан интервал");
        } catch(NumberFormatException exception) {
            JOptionPane.showMessageDialog( null, "Неверный ввод чисел");
        }

    }
}