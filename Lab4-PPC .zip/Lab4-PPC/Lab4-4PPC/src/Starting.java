public class Starting {
    public static void main(String[] args) {
        new Task4();
    }
}
