import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JFrame;

class Logo extends Canvas {
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Rectangle r = g.getClipBounds();
        g.setColor(new Color(0, 249, 255));
        g.fillRect(r.x + 10, r.y + 10, r.width - 20, (r.height - 20)/5);
        g.setColor(new Color(0, 212, 247));
        g.fillRect(r.x + 10, r.y + 10 + 2*(r.height - 20)/5, r.width - 20, (r.height - 20)/5);
        g.setColor(new Color(0, 182, 248));
        g.fillRect(r.x + 10, r.y + 10 + 4*(r.height - 20)/5, r.width - 20, (r.height - 20)/5);
        g.setColor(new Color(0, 48, 209));
        int[] xPoints1 = {r.x + 10 +(r.width- 20)/4, r.x + 10 + 3*(r.width- 20)/4, r.x + 10 + 2*(r.width- 20)/4};
        int[] yPoints1 = {r.y + 10, r.y + 10, r.y + 10 + (r.height - 20)/5};
        g.fillPolygon(xPoints1, yPoints1, 3);
        g.setColor(new Color(0xb40000));
        int[] xPoints2 = {r.x + 10 +(r.width- 20)/4, r.x + 10 + 3*(r.width- 20)/4, r.x + 10 + 2*(r.width- 20)/4};
        int[] yPoints2 = {r.y + (r.height - 10), r.y + (r.height - 10), r.y + 10 + 4*(r.height - 20)/5};
        g.fillPolygon(xPoints2, yPoints2, 3);
        g.setColor(new Color(154, 253, 255));
        g.fillOval(r.x + 10 + (r.width- 20)/4, r.y + 10 + (r.height - 20)/5, (r.width-20)/2, 3*(r.height - 20)/5);
        g.setColor(new Color(57, 0, 157));
        int[] xPoints3 = {r.x + 10, r.x + 10 + (r.width- 20)/4, r.x + (r.width- 10), r.x + 10 + 3*(r.width - 20)/4};
        int[] yPoints3 = {r.y + 10 + (r.height - 20)/5, r.y + 10 + (r.height - 20)/5, r.y + 10 + 4*(r.height - 20)/5, r.y + 10 + 4*(r.height - 20)/5};
        g.fillPolygon(xPoints3, yPoints3, 4);
        g.setColor(Color.WHITE);
        g.fillOval(r.x + 10 + 3*(r.width- 20)/8, r.y + 10 + 2*(r.height - 20)/5, (r.width-20)/4, (r.height - 20)/5);
    }
}
class Task3 extends JFrame {
    public Task3(){
        super("Задание 3");
        setBounds(700, 350, 380, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new Logo());
        validate();
        setVisible(true);
    }
}
public class Starting {
    public static void main(String[] args) {
        new Task3();
    }
}
