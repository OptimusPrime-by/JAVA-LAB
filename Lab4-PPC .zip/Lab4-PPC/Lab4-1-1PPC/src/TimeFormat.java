public class TimeFormat {
    private int hours = 0;
    private int seconds = 0;

    public int DataHours() {
        return hours;
    }

    public boolean StringToTime(String str) {
        boolean test1 = true;
        boolean test2;
        boolean test3;
        if (str.length() != 5) test1 = false;
        String[] arrSplit = str.split(":");
        test2 = Checking.CheckDigit(arrSplit);
        int[] timeArr = new int[2];
        if (test1 && test2) {
            for (int i = 0; i < 2; i++) {
                timeArr[i] = Integer.parseInt(arrSplit[i]);
            }
            test3 = Checking.CheckTime(timeArr[0], timeArr[1]);
            if(test3) {
                hours = timeArr[0];
                seconds = timeArr[1];
                return true;
            }
            else return false;
        }
        else return false;
    }
    public String TimeToString(){
        String formatted = hours + ":" + seconds;
        StringBuilder strB = new StringBuilder(formatted);
        if(hours < 10) strB.insert(0, '0');
        if(seconds < 10) strB.insert(3, '0');
        formatted = strB.toString();
        return formatted;
    }
    public boolean NewTimeData(int number){
        if(number < 0) return false;
        else{
            if(number > (23 - hours)) {
                hours-=number;
                while (hours < 0)
                    hours += 24;
            }
            else{
                hours -= number;
            }
            return true;
        }
    }
}
