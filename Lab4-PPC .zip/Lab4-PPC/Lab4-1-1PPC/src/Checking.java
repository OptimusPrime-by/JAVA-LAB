public class Checking {
    public static boolean CheckDigit(String[] time){
        boolean test = true;
        int count = 0;
        for (int i = 0; i < time.length; i++) {
            count++;
            char[] Array = time[i].toCharArray();
            for (int j = 0; j < Array.length; j++) {
                if (!Character.isDigit(Array[j])) {
                    test = false;
                }
            }
        }
        if (count != 2) test = false;
        return test;
    }
    public static boolean CheckTime(int h, int s){
        boolean test = true;
        if(h < 0 || h > 23) test = false;
        if(s < 0 || s > 59) test = false;
        return test;
    }
    public static int CheckTask1(int h1, int h2){
        if(h1 > h2) return 1;
        else if(h1 == h2) return 2;
        else return 3;
    }
}
