import java.awt.event.ActionEvent; //события
import java.awt.event.ActionListener; // обработчик событий

import javax.swing.JButton; //кнопка
import javax.swing.JFrame; //создает пустое окно с заголовком title. Контейнер
import javax.swing.JLabel; //отображение информации, картинки и тд.
import javax.swing.JOptionPane; // диалоговое окно
import javax.swing.JTextField; // поле ввода

class Task1 extends JFrame{
    public static JTextField ResultText = new JTextField();
    public Task1() {
        super("Задание 1");
        setBounds(400, 400, 380, 320);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel TimeLabel = new JLabel("Введите время (Формат XX:XX):");
        TimeLabel.setBounds(10, 10, 350, 30);
        add(TimeLabel);
        JTextField TimeText = new JTextField();
        TimeText.setBounds(10, 50, 350, 30);
        add(TimeText);
        JLabel NumberLabel = new JLabel("Введите целое число:");
        NumberLabel.setBounds(10, 90, 350, 30);
        add(NumberLabel);
        JTextField NumberText = new JTextField();
        NumberText.setBounds(10, 130, 350,30);
        add(NumberText);
        JButton NewTimeButton = new JButton("Выполнить");
        NewTimeButton.setBounds(60, 170, 250, 30);
        NewTimeButton.addActionListener(new NewTimeButtonHandler(TimeText, NumberText));
        add(NewTimeButton);
        ResultText.setBounds(10, 220, 350,30);
        add(ResultText);
        ResultText.setEditable(false);
        validate();
        setVisible(true);
    }
}

class NewTimeButtonHandler implements ActionListener {
    private JTextField Time, Num;
    public NewTimeButtonHandler(JTextField Time, JTextField Num){
        this.Time = Time;
        this.Num = Num;
    }
    @Override
    public void actionPerformed(ActionEvent event) {
        try {
            String TimeStr1 = Time.getText();
            String TimeStr2;
            int Number = Integer.parseInt(Num.getText());
            TimeFormat time = new TimeFormat();
            if(time.StringToTime(TimeStr1)){
                int hours1 = time.DataHours();
                if(time.NewTimeData(Number)){
                    TimeStr2 = time.TimeToString();
                    int buf = Checking.CheckTask1(hours1, time.DataHours());
                    if (buf == 1) Task1.ResultText.setText(TimeStr2 + " | В прошлом");
                    if (buf == 2) Task1.ResultText.setText(TimeStr2 + " | Даты равны");
                    if (buf == 3) Task1.ResultText.setText(TimeStr2 + " | В будущем");
                }
                else JOptionPane.showMessageDialog( null, "Число не должно быть отрицательным");
            }
            else JOptionPane.showMessageDialog( null, "Неверный формат времени");
        } catch(NumberFormatException exception) {
            JOptionPane.showMessageDialog( null, "Неверный ввод");
        }

    }
}

public class Starting {
    public static void main(String[] args) {
        new Task1();
    }
}
