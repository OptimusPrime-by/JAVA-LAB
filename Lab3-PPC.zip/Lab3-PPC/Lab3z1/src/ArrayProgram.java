import java.math.BigDecimal;
import java.util.Scanner;
public class ArrayProgram {
    private Double[] Array; // массив
    private int N;
    public void CreateRandom(boolean start){
        if(start) Array = null;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите колличество элементов массива:");
        if(scanner.hasNextInt()) {
            N = scanner.nextInt();
            Array = new Double[N];
            for (int i = 0; i < N; i++) {
                Array[i] = (double) Math.round((Math.random() * i * 100)) + (double) Math.round((Math.random() * i * 10)) + (double) Math.round((Math.random() * i));
            }
            System.out.println("Массив задан случайным образом.");
        }
        else System.out.println("Вы ввели неправильное колличество элементов. Массив не задан");
    }
    public void CreateIn(boolean start){
        if(start) Array = null;
        Scanner scanner = new Scanner(System.in);
        String scan;
        System.out.println("Введите колличество элементов массива:");
        if(scanner.hasNextInt()) {
            N = scanner.nextInt();
            Array = new Double[N];
            System.out.println("Введите элементы массив типа double.");
            int number = 0;
            for (int i = 0; i < N; i++) {
                number++;
                if(scanner.hasNextDouble()) {
                    Array[i] = scanner.nextDouble();
                }
                else {
                    System.out.println("Введён неправильный элемент массива. " + number + "-ый элемент не будет записан в массив.");
                    scan = scanner.next();
                    i--;
                    N--;
                }
            }
            System.out.println("Массив задан пользователем.");
        }
        else System.out.println("Вы ввели неправильное колличество элементов. Массив не задан");
    }
    public void Out(){
        System.out.println("Вывод массива:");
        if(N!=0) {
            for (int i = 0; i < N; i++) {
                System.out.println(Array[i]);
            }
        }
        else System.out.println("Массив пуст.");
    }
    public void Processing() {
        double first = 0;
        double last = 0;
        int indexF = -1, indexL = -1;
        for (int i = 0; i < N; i++) {
            first = Array[i];
            if (Testing.TestA(first)) {
                indexF = i;
                break;
            }
        }
        for (int i = N - 1; i >= 0; i--) {
            last = Array[i];
            if (Testing.TestA(last)) {
                indexL = i;
                break;
            }
        }
        if (indexF != indexL) {
            String str = "" + first;
            BigDecimal decimal_1 = new BigDecimal(str);
            str = "" + last;
            BigDecimal decimal_2 = new BigDecimal(str);
            BigDecimal decimal_k = decimal_1.multiply(decimal_2);
            double k = decimal_k.doubleValue();
            System.out.println("Произведение элементов массива между первым и последним элементами, удовлетворяющими условию: " + k);
        }
        else System.out.println("В массиве не найдены элементы, удовлетворяющие условию.");

    }
    public void Change(){
        double buf;
        for(int i = 0; i < N; i++) {
            buf = Array[i];
            int Delete = (int) buf;
            if (Testing.TestB(Delete)){
                System.out.println("Удаление элемента " + Delete + ".");
                Array[i] = null;
                for(int j = i; j < N-1; j++) Array[j] = Array[j+1];
                i--;
                N--;
            }
        }
        System.out.println("Обработка завершена.");
    }
    public void Exit(){
        System.exit(0);
    }
}
