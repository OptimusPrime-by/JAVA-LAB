import java.math.BigDecimal;

public class Testing {
    public static boolean TestA(double a){
        double e = 2.7;
        double E = Math.pow(10, -5);
        String str_Double = "" + a;
        BigDecimal decimal_1 = new BigDecimal(str_Double); // BigDecimal - класс, для сколь угодно длинного вещественного числа
        str_Double = "" + e;
        BigDecimal decimal_2 = new BigDecimal(str_Double);
        BigDecimal decimal_k = decimal_1.subtract(decimal_2);
        double k = Math.abs(decimal_k.doubleValue());
        return(k <= E);
    }
    public static boolean TestB(int a){
        boolean test = true;
        boolean test1 = true;
        int buf = a % 10;
        a = (a - buf)/10;
        if(a != 0) {
            int buf1 = a % 10;
            double q = (double) buf1 / buf;
            a = (a - buf1) / 10;
            test1 = (buf > buf1);
            while (a != 0) {
                buf = a % 10;
                a = (a - buf) / 10;
                if (q != (double) buf / buf1) {
                    test = false;
                    break;
                }
                buf1 = buf;
            }
        }
        else test = false;
        if(!test1) test =false;
        return test;
    }
}
