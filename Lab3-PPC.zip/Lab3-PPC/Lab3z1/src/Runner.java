import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        int Command;
        ArrayProgram Prog = new ArrayProgram();
        System.out.println("1.Заполнение массива случайным образом\n2.Ввод элементов массива с клавиатуры\n3.Выход из программы");
        Scanner scanner = new Scanner(System.in);
        if (scanner.hasNextInt()) {
            Command = scanner.nextInt();
            switch (Command) {
                case 1:
                    Prog.CreateRandom(true);
                    break;
                case 2:
                    Prog.CreateIn(true);
                    break;
                case 3:
                    Prog.Exit();
                    break;
                default:
                    System.out.println("Неправильно введена комманда.");
            }
        }
        else System.out.println("Неправильно введена комманда.");
        System.out.println("1.Заполнение массива случайным образом\n2.Ввод элементов массива с клавиатуры\n3.Вывод элементов массива на экран\n4.Обработка массива\n5.Изменение массива\n6.Выход из программы");
        while(true) {
            if (scanner.hasNextInt()) {
                Command = scanner.nextInt();
                switch (Command) {
                    case 1:
                        Prog.CreateRandom(true);
                        break;
                    case 2:
                        Prog.CreateIn(true);
                        break;
                    case 3:
                        Prog.Out();
                        break;
                    case 4:
                        Prog.Processing();
                        break;
                    case 5:
                        Prog.Change();
                        break;
                    case 6:
                        Prog.Exit();
                        break;
                    default:
                        System.out.println("Неправильно введена комманда.");
                }
            }
            else System.out.println("Неправильно введена комманда.");
            System.out.println("Ожидание команды.");
        }
    }
}
//1 2 3 11,00001 0000  2,7 1000 124 0,1 1 2 139 0,01 0,001 0,0000001 0,00099 248,9999 12fjd 02020kd 9999 2,699999 :   21