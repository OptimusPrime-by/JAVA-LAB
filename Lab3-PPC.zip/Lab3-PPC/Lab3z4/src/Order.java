import java.io.Serializable;
import java.util.Scanner;

public class Order implements Serializable {
    public Integer ID;
    public String SecondName;
    public String Initials;
    public String OrderName;
    public int number;
    public double CostForOne, CostForNumber;

    public boolean Input(int NumID) {
        boolean test = true;
        Scanner scanner = new Scanner(System.in);
        ID = NumID;
        String[] Registration = new String[3];
        for (int i = 0; i < 3; i++) {
            Registration[i] = scanner.next();
        }
        if (Checking.ChekName(Registration[0])) SecondName = Registration[0];
        else test = false;
        if (Checking.ChekInitials(Registration[1])) Initials = Registration[1];
        else test = false;
        if (!Registration[2].equals(" ")) {
            String[] arrSplitReg = Registration[2].split("_");
            OrderName = String.join(" ", arrSplitReg);
        }
        else test = false;
        if (scanner.hasNextInt()) {
        number = scanner.nextInt();
        if(number <= 0) test = false;
        }
        else test = false;
        if (scanner.hasNextDouble()) {
            CostForOne = scanner.nextDouble();
            if(CostForOne <= 0) test = false;
            else if(!Checking.CheckDollar(CostForOne)) test = false;
        }
        else test = false;
        if(test) CostForNumber = CostForOne * number;
        return test;
    }
    public void Output(){
        System.out.println(ID + "." + SecondName + " " + Initials + " " + OrderName + " " + number + " ед. Стоимость единицы товара: " + CostForOne + "$");
    }
    public void OutputCustomer(int index){
        System.out.print(index + "."  + OrderName + " " + number + " ед. Общая стоимость заказа: " + CostForNumber + "$");
    }
    public void OutputItem(int index){
        System.out.print(index + "."  + SecondName + " " + Initials + " " + number + " ед. Общая стоимость заказа: " + CostForNumber + "$");
    }
}
