import java.io.*;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.ArrayList;

public class Starting {
    private static Map<Integer, Order> orders = new HashMap();
    public static void main(String[] args){
        int Command;
        String way = args[0];
        Scanner scanner = new Scanner(System.in);
        if(way.equals("file")) InputStreamFile();
        else if(way.equals("console")){
            System.out.println("Сколько заказов вы хотите зарегистрировать?");
            if(scanner.hasNextInt()) {
                int count = scanner.nextInt();
                System.out.println("Зарегистрируйте заказ. Формат: (Фамилия) (И.О.) (название_товара) (количество товара) (стоимость единицы товара в $)");
                while(count > 0) {
                    Order Reg = new Order();
                    boolean F = Reg.Input(orders.size()+1);
                    if (F) {
                        orders.put(Reg.ID, Reg);
                        System.out.println("Заказ прошёл регистрацию");
                    } else System.out.println("Недостаточно параметров для регистрации");
                    count--;
                }
            }
        }
        else {
            System.out.println("Неверный способ ввода.");
            System.exit(0);
        }
        System.out.println("1.Регистрация заказа\n2.Вывод списка заказов\n3.Сохранение списка в файл\n4.Вывести для каждого покупателя список заказов с суммарной стоимостью всех его заказов\n5.Вывести для каждого товара список заказов с суммарной стоимостью\n6.Удалить зарегистрированный заказ из списка\n7.Выход из программы");
        while (true) {
            if (scanner.hasNextInt()) {
                Command = scanner.nextInt();
                switch (Command) {
                    case 1 -> {
                        System.out.println("Зарегистрируйте заказ. Формат: (Фамилия) (И.О.) (название_товара) (количество товара) (стоимость единицы товара в $)");
                        Order Reg = new Order();
                        boolean F = Reg.Input(orders.size()+1);
                        if (F) {
                            orders.put(Reg.ID, Reg);
                            System.out.println("Заказ прошёл регистрацию");
                        } else System.out.println("Недостаточно параметров для регистрации");
                    }
                    case 2 -> OutputOrdersArray();
                    case 3 -> OutputStreamFile();
                    case 4 -> {
                        ArrayList<String> ArraySN = new ArrayList<>();
                        ArrayList<String> ArrayIN = new ArrayList<>();
                        for (int i = 0; i < orders.size(); i++) {
                            ArraySN.add(orders.get(i + 1).SecondName);
                            ArrayIN.add(orders.get(i + 1).Initials);
                        }
                        if (ArraySN.size() == 0) System.out.println("Нет зарегистрированных заказов.");
                        for (int i = 0; i < ArraySN.size(); i++) {
                            System.out.println((i+1) + "." + ArraySN.get(i) + " " + ArrayIN.get(i) + " :");
                            OutputOrdersCustomer(ArraySN.get(i), ArrayIN.get(i));
                            for (int j = i + 1; j < ArraySN.size(); j++){
                                if (ArraySN.get(i).equals(ArraySN.get(j)) && ArrayIN.get(i).equals(ArrayIN.get(j))) {
                                    ArraySN.remove(j);
                                    ArrayIN.remove(j);
                                    j--;
                                }
                            }
                        }
                    }
                    case 5 -> {
                        ArrayList<String> ArrayON = new ArrayList<>();
                        for (int i = 0; i < orders.size(); i++) {
                            ArrayON.add(orders.get(i + 1).OrderName);
                        }
                        if (ArrayON.size() == 0) System.out.println("Нет зарегистрированных заказов.");
                        for (int i = 0; i < ArrayON.size(); i++) {
                            System.out.println((i+1) + "." + ArrayON.get(i) + " :");
                            OutputOrdersItem(ArrayON.get(i));
                            for (int j = i + 1; j < ArrayON.size(); j++){
                                if (ArrayON.get(i).equals(ArrayON.get(j))) {
                                    ArrayON.remove(j);
                                    j--;
                                }
                            }
                        }

                    }
                    case 6 -> {
                        System.out.println("Введите номер заказа, который хотите удалить из списка.");
                        if (scanner.hasNextInt()) {
                            int IndexDelete = scanner.nextInt() - 1;
                            if (IndexDelete >= 0 && IndexDelete < orders.size()) {
                                orders.get(IndexDelete+1).Output();
                                System.out.println("Подтвердите удаление заказа. (Да/Нет)");
                                String consent = scanner.next();
                                if (consent.equals("Да")) {
                                    orders.remove(IndexDelete+1);
                                    System.out.println("Заказ удалён из списка.");
                                } else if (consent.equals("Нет")) System.out.println("Заказ не будет удалён из списка.");
                                else System.out.println("Ошибка ввода подтверждения. Заказ не будет удалён из списка.");
                            } else System.out.println("Неверный номер");
                        } else System.out.println("Неверный номер.");
                    }
                    case 7 -> System.exit(0);
                    default -> System.out.println("Неправильно введена комманда.");
                }
            }
            else System.out.println("Неправильно введена комманда.");
        }
    }
    private static void InputStreamFile(){
        try {
            InputStream is = new FileInputStream("G:\\My\\Proga\\Lab3-PPC\\fileOrders.bin");
            ObjectInputStream ois = new ObjectInputStream(is);
            orders = (Map<Integer, Order>)ois.readObject();
            ois.close();
            System.out.println("Список введён из файла");
        } catch(IOException | ClassNotFoundException e) {
            System.out.println("Невозможно прочитать файл");
        }
    }
    private static void OutputStreamFile(){
        try {
            OutputStream os = new FileOutputStream("G:\\My\\Proga\\Lab3-PPC\\fileOrders.bin");
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(orders);
            oos.close();
            System.out.println("Список сохранён в файл");
        } catch(IOException e) {
            System.out.println("Невозможно сохранить файл");
        }
    }

    private static void OutputOrdersArray(){
        if(orders.size() == 0) System.out.println("Нет зарегистрированных заказов.");
        else {
            for (int i = 0; i < orders.size(); i++) {
                orders.get(i+1).Output();
            }
        }
    }
    private static void OutputOrdersCustomer(String strSN, String strIn){
        BigDecimal CostForAll = new BigDecimal(0);
        int indexOrder = 1;
        for(int i = 0; i < orders.size(); i++){
            if(orders.get(i+1).SecondName.equals(strSN) && orders.get(i+1).Initials.equals(strIn)){
                orders.get(i+1).OutputCustomer(indexOrder);
                String str_Double = "" + orders.get(i+1).CostForNumber;
                BigDecimal decimal_1 = new BigDecimal(str_Double);
                CostForAll = CostForAll.add(decimal_1);
                System.out.println();
                indexOrder++;
            }
        }
        double k = CostForAll.doubleValue();
        System.out.println("Итог: " + CostForAll + "$");
    }
    private static void OutputOrdersItem(String strON){
        BigDecimal CostForAll = new BigDecimal(0);
        int indexOrder = 1;
        for(int i = 0; i < orders.size(); i++){
            if(orders.get(i+1).OrderName.equals(strON)){
                orders.get(i+1).OutputItem(indexOrder);
                String str_Double = "" + orders.get(i+1).CostForNumber;
                BigDecimal decimal_1 = new BigDecimal(str_Double);
                CostForAll = CostForAll.add(decimal_1);
                System.out.println();
                indexOrder++;
            }
        }
        double k = CostForAll.doubleValue();
        System.out.println("Итог: " + k + "$");
    }
}
// Щелкунова К.В. коврик_для_мыши 1 3,38
// Бондарь Д.Т. коврик_для_мыши 1 3,68
// Щелкунова К.В. игровой_ноутбук 1 6398
// Валиулин Д.Л. беспроводные_наушники 1 56,30
// Бочарова Н.К. тушь 2 2,81