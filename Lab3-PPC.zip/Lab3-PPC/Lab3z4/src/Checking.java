public class Checking {
    public static boolean CheckDollar(double cost){
        boolean test = true;
        cost*=100;
        int delete = (int) cost;
        cost -= delete;
        return (cost == 0);
    }
    public static boolean ChekName(String str){
        boolean test = true;
        char[] Array = str.toCharArray();
        for(int i = 0; i < Array.length; i++)
            if(!Character.isLetter(Array[i]))
                test = false;

        return test;
    }
    public static boolean ChekInitials(String str) {
        boolean test = true;
        char[] Array = str.toCharArray();
        if (Array.length == 4 && Array[1] == '.' && Array[3] == '.') {
            if (!Character.isLetter(Array[0]) || !Character.isLetter(Array[2]))
                test = false;
        } else test = false;

        return test;
    }
}
