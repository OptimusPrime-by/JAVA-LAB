import java.awt.desktop.SystemEventListener;
import java.lang.module.InvalidModuleDescriptorException;

public class ArrayHandler {
    private double[][] Array;
    private int K = 0;
    private int N = -1;

    private void CreateArray(){Array = new double[100][N];}
    public boolean Record(String str){
        boolean test = true;
        String[] arrSplit = str.split(";");
        if(Check.CheckRecord(arrSplit)){
            K++;
            if(N == -1) {
                N = arrSplit.length;
                CreateArray();
            }
            else {
                int N1 = arrSplit.length;
                if(N1 != N) test = false;
            }
            if(test) {
                for (int i = 0; i < arrSplit.length; i++) {
                    char[] ArrayCells = arrSplit[i].toCharArray();
                    Array[K-1][i] = Double.parseDouble(arrSplit[i]);
                }

                return(K != 101);
            }
            else {
                System.out.println("Не равное колличество столбцов в строках.");
                return false;
            }
        }
        else{
            System.out.println("Ошибка ввода-вывода массив чисел.");
            return false;
        }
    }
    public void Release(){
        int count = 0;
        for(int i = 99; i >= K; i--){
            for(int j = 0; j < N; j++){
                Array[i][j] = 0;
            }
            count++;
        }
    }

    public void Input(){
        for(int i = 0; i < K; i++){
            for(int j = 0; j < N; j++) System.out.print(Array[i][j] + " ");
            System.out.println();
        }
    }

    public void Task2(){
        double max = Array[0][0];
        int indexI = 0;
        int indexJ = 0;
        for(int i = 0; i < K; i++){
            for(int j = 0; j < N; j++) {
                if(Array[i][j] >= max){
                    max = Array[i][j];
                    indexI = i;
                    indexJ = j;
                }
            }
        }
        System.out.println("1.Последний из максимальных элементов в массиве:");
        System.out.println("Индекс строки: " + indexI + " Индекс столбца: " + indexJ + " Число: " + max);
        System.out.println("2.Первый минимальный элемент среди элементов массива, расположенных правее и ниже найденного элемента в 1.:");
        if(indexI != K-1 && indexJ != N-1) {
            double min = Array[indexI + 1][indexJ + 1];
            int indexI1 = indexI + 1;
            int indexJ1 = indexJ + 1;
            for (int i = indexI + 1; i < K; i++) {
                for (int j = indexJ + 1; j < N; j++) {
                    if (Array[i][j] < min) {
                        min = Array[i][j];
                        indexI1 = i;
                        indexJ1 = j;
                    }
                }
            }
            System.out.println("Индекс строки: " + indexI1 + " Индекс столбца: " + indexJ1 + " Число: " + min);
        }
        else System.out.println("Элементов не существует в данном диапазоне");
    }
}
