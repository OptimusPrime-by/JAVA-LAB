import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class Start {
    public static void main(String[] args) {
        ArrayHandler handler = new ArrayHandler();
        boolean test1 = true;
        try {
            Reader reader = new FileReader("G:\\CSV1.csv");
            BufferedReader buffReader = new BufferedReader(reader);
            String line;
            while ((line = buffReader.readLine()) != null && test1) {
      //          System.out.println(line);
                test1 = handler.Record(line);
            }
            buffReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Файл не найден");
        } catch (IOException e) {
            System.out.println("Ошибка ввода-вывода");
        }
        if(test1){
            handler.Release();
            handler.Input();
            handler.Task2();
        }
    }
}
