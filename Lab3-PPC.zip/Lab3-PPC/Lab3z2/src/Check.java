public class Check {
    public static boolean CheckRecord(String[] cells){
        boolean test = true;
        for (int i = 0; i < cells.length; i++) {
            char[] Array = cells[i].toCharArray();
            for (int j = 0; j < Array.length; j++) {
                if (!Character.isDigit(Array[j])) {
                    test = false;
                }
            }
        }
        return test;
    }
}
