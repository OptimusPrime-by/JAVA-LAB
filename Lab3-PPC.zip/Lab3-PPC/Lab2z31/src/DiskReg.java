import java.io.Serializable; // стандартный алгоритм сериализации.Процесс перевода
import java.util.Scanner;

public class DiskReg implements Serializable {
    public String SecondName;
    public String Initials;
    public String DiskName;
    public Date DateOfIssue = new Date(), DateOfReturn = new Date(), DateOfFactReturn = new Date();

    public boolean Input() {
        System.out.println("Зарегистрируйте диск. Формат: (Фамилия) (И.О.) (название_диска) (дата выдачи) (дата назначенного возврата) (дата фактического возврата)");
        boolean SN, Ins, DN, DOI, DOR, DOR1 = false, DOFR;
        boolean test = true;
        Scanner scanner = new Scanner(System.in);
        String[] Registration = new String[6];
        for (int i = 0; i < 6; i++) {
            Registration[i] = scanner.next();
        }
        if (Checking.ChekName(Registration[0])) {
            SecondName = Registration[0];
            SN = true;
        } else {
            SecondName = "XX";
            SN = false;
        }
        if (Checking.ChekInitials(Registration[1])) {
            Initials = Registration[1];
            Ins = true;
        } else {
            Initials = "X.X.";
            Ins = false;
        }
        if (!Registration[2].equals(" ")) {
            String[] arrSplitReg = Registration[2].split("_");
            DiskName = String.join(" ", arrSplitReg);
            DN = true;
        } else {
            DiskName = "Неизвестно";
            DN = false;
        }
        DOI = DateOfIssue.Format(Registration[3]);
        DOR = DateOfReturn.Format(Registration[4]);
        if (DOR)
            DOR1 = Checking.ChekDateReturn(DateOfIssue.DataDay(), DateOfIssue.DataMonth(), DateOfIssue.DataYear(), DateOfReturn.DataDay(), DateOfReturn.DataMonth(), DateOfReturn.DataYear());
        DOFR = DateOfFactReturn.Format(Registration[5]);
        if (DOFR)
            if (!Checking.ChekDateReturn(DateOfIssue.DataDay(), DateOfIssue.DataMonth(), DateOfIssue.DataYear(), DateOfFactReturn.DataDay(), DateOfFactReturn.DataMonth(), DateOfFactReturn.DataYear())) {
                DateOfFactReturn.SetDataDay(-1);
                DateOfFactReturn.SetDataMonth(-1);
                DateOfFactReturn.SetDataYear(-1);
            }
        if (!SN || !Ins) test = false;
        else if (!DN && !DOI) test = false;
        else if (!DOR1) test = false;
        return test;
    }

    public void Output(int number) {
        System.out.print(number + "." + SecondName + " " + Initials + " " + DiskName + " ");
        DateOfIssue.Out();
        System.out.print(" ");
        DateOfReturn.Out();
        System.out.print(" ");
        DateOfFactReturn.Out();
        System.out.println();
    }

    public boolean DiskDebt() {
        boolean test = true;
        if (DateOfFactReturn.DataDay() == -1) {
            if (Checking.ChekDateReturn(DateOfReturn.DataDay(), DateOfReturn.DataMonth(), DateOfReturn.DataYear(), 19, 11, 2021))
                test = false;
        } else if (Checking.ChekDateReturn(DateOfReturn.DataDay(), DateOfReturn.DataMonth(), DateOfReturn.DataYear(), DateOfFactReturn.DataDay(), DateOfFactReturn.DataMonth(), DateOfFactReturn.DataYear()))
            test = false;
        return test;
    }

    public void OutputDebt(int number) {
        System.out.println(number + "." + SecondName + " " + Initials);
    }

    public void ChangeData(int number) {
        boolean DN, DOI, DOR, DOR1 = false, DOFR;
        Scanner scanner = new Scanner(System.in);
        String reData = scanner.next();
        System.out.println("Введите изменённые данные.");
        String consent;
        DN = DiskName.equals("Неизвестно");
        DOI = (DateOfIssue.DataDay() == -1);
        Date DateChange = new Date();
        switch (number) {
            case 1 -> {
                System.out.println("Изменить " + SecondName + " на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    if (Checking.ChekName(reData)) {
                        SecondName = reData;
                        System.out.println("Фамилия изменена.");
                    } else {
                        System.out.println("Ошибка ввода. Фамилия не будет изменена.");
                    }
                } else if (consent.equals("Нет")) System.out.println("Фамилия не будет изменена.");
                else System.out.println("Ошибка ввода подтверждения. Фамилия не будет изменена.");
            }
            case 2 -> {
                System.out.println("Изменить " + Initials + " на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    if (Checking.ChekInitials(reData)) {
                        Initials = reData;
                        System.out.println("Инициалы изменены.");
                    } else {
                        System.out.println("Ошибка ввода. Инициалы не будут изменены.");
                    }
                } else if (consent.equals("Нет")) System.out.println("Инициалы не будут изменены.");
                else System.out.println("Ошибка ввода подтверждения. Инициалы не будут изменены.");
            }
            case 3 -> {
                System.out.println("Изменить " + DiskName + " на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    if (!reData.equals(" ")) {
                        String[] arrSplitReg = reData.split("_");
                        DiskName = String.join(" ", arrSplitReg);
                        System.out.println("Название диска изменено.");
                    } else {
                        if (DOI) {

                            System.out.println("Название диска теперь неизвестно.");
                        } else
                            System.out.println("Не хватает данных в регистрации диска. Название диска не будет изменено.");
                    }
                } else if (consent.equals("Нет")) System.out.println("Название диска не будет изменено.");
                else System.out.println("Ошибка ввода подтверждения. Название диска не будет изменено.");
            }
            case 4 -> {
                System.out.print("Изменить ");
                DateOfIssue.Out();
                System.out.println(" на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    DOI = DateChange.Format(reData);
                    if (DOI && DateChange.DataDay() != -1) {
                        DateOfIssue = DateChange;
                        System.out.println("Дата изменена.");
                    } else {
                        if (DN) {
                            DateOfIssue.SetDataDay(DateChange.DataDay());
                            DateOfIssue.SetDataMonth(DateChange.DataMonth());
                            DateOfIssue.SetDataYear(DateChange.DataYear());
                            System.out.println("Дата теперь неизвестна.");
                        } else
                            System.out.println("Не хватает данных в регистрации диска. Дата не будет изменена.");
                    }
                } else if (consent.equals("Нет")) System.out.println("Дата не будет изменена.");
                else System.out.println("Ошибка ввода подтверждения. Дата не будет изменена.");
            }
            case 5 -> {
                System.out.print("Изменить ");
                DateOfReturn.Out();
                System.out.println(" на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    DOR = DateChange.Format(reData);
                    if (DOR) {
                        if (Checking.ChekDateReturn(DateOfIssue.DataDay(), DateOfIssue.DataMonth(), DateOfIssue.DataYear(), DateChange.DataDay(), DateChange.DataMonth(), DateChange.DataYear())) {
                            DateOfReturn.SetDataDay(DateChange.DataDay());
                            DateOfReturn.SetDataMonth(DateChange.DataMonth());
                            DateOfReturn.SetDataYear(DateChange.DataYear());
                            System.out.println("Дата изменена.");
                        }
                    } else System.out.println("Ошибка ввода. Дата не будет изменена.");

                } else if (consent.equals("Нет")) System.out.println("Дата не будет изменена.");
                else System.out.println("Ошибка ввода подтверждения. Дата не будет изменена.");
            }
            case 6 -> {
                System.out.print("Изменить ");
                DateOfFactReturn.Out();
                System.out.println(" на " + reData + "?(Да/Нет)");
                consent = scanner.next();
                if (consent.equals("Да")) {
                    DOFR = DateOfFactReturn.Format(reData);
                    if (DOFR) {
                        if (!Checking.ChekDateReturn(DateOfIssue.DataDay(), DateOfIssue.DataMonth(), DateOfIssue.DataYear(), DateOfFactReturn.DataDay(), DateOfFactReturn.DataMonth(), DateOfFactReturn.DataYear())) {
                            DateOfFactReturn.SetDataDay(-1);
                            DateOfFactReturn.SetDataMonth(-1);
                            DateOfFactReturn.SetDataYear(-1);
                        }
                        if (DateOfFactReturn.DataDay() == -1) System.out.println("Дата теперь неизвестна.");
                        else System.out.println("Дата изменена.");
                    } else if (consent.equals("Нет")) System.out.println("Дата не будет изменена.");
                    else System.out.println("Ошибка ввода подтверждения. Дата не будет изменена.");
                }
            }
        }
    }
}
