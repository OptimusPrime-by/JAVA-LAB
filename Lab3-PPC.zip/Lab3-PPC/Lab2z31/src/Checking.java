public class Checking {
    public static boolean ChekName(String str){
        boolean test = true;
        char[] Array = str.toCharArray();
        for(int i = 0; i < Array.length; i++)
            if(!Character.isLetter(Array[i]))
                test = false;

        return test;
    }
    public static boolean ChekInitials(String str) {
        boolean test = true;
        char[] Array = str.toCharArray();
        if (Array.length == 4 && Array[1] == '.' && Array[3] == '.') {
            if (!Character.isLetter(Array[0]) || !Character.isLetter(Array[2]))
                test = false;
        } else test = false;

        return test;
    }

    public static boolean CheckDigit(String[] date){
        boolean test = true;
        int count = 0;
        for (int i = 0; i < date.length; i++) {
            count++;
            char[] Array = date[i].toCharArray();
            for (int j = 0; j < Array.length; j++)
                if (!Character.isDigit(Array[j]))
                    test = false;
        }
        if (count != 3) test = false;
        return test;
    }
    public static boolean CheckDate(int day, int month, int year){
        boolean test = true;
        if (year > 0 && year < 10000 && month > 0 && month < 13 && day > 0) {
            if (month == 4 || month == 6 || month == 9 || month == 11) {
                if(day > 30) test = false;
            }
            else if (month == 2) {
                if (year % 4 == 0 && year % 100 != 0) {
                    if(day > 28) test = false;
                }
                else if(day > 29) test = false;
            }
            else if(day > 31) test = false;

        }
        else test = false;

        return test;
    }
    public static boolean ChekDateReturn(int day1, int month1, int year1, int day2, int month2, int year2){
        boolean test = false;
        if(year1 < year2) test = true;
        else {
            if (month1 < month2) test = true;
            else if(day1 < day2) test = true;
        }
        return test;
    }
}
