import java.io.FileInputStream; //используется для чтения потоков необработанных байтов
import java.io.FileOutputStream; //предназначается для записи потоков необработанных байтов
import java.io.IOException; //исключения ввода-вывода
import java.io.InputStream; //базовые методы для работы с байтовыми потоками данных.
import java.io.ObjectInputStream; //методы для чтения объекта из InputStream, которым он управляет
import java.io.ObjectOutputStream; //методы для записи объекта в OutputStream, которым он управляет
import java.io.OutputStream; //потоковый байтовый вывод
import java.util.ArrayList;
import java.util.Scanner;

public class Starting {
    private static ArrayList<DiskReg> disks = new ArrayList<>();
    public static ArrayList<DiskReg> disksDebt = new ArrayList<>();
    public static void main(String[] args){

        InputStreamFile();
        int Command;

        System.out.println("1.Регистрация диска\n2.Вывод списка зарегистрированных\n3.Вывести список фамилий должников\n4.Редактировать зарегистрированный диск\n5.Удалить зарегистрированный диск из списка\n6.Выход из программы");
        while (true) {
            Scanner scanner = new Scanner(System.in);
            if (scanner.hasNextInt()) {
                Command = scanner.nextInt();
                switch (Command) {
                    case 1 -> {
                        DiskReg Reg = new DiskReg();
                        boolean F = Reg.Input();
                        if (F) {
                            disks.add(Reg);
                            OutputStreamFile();
                            System.out.println("Диск прошёл регистрацию");
                        } else System.out.println("Недостаточно параметров для регистрации");
                    }
                    case 2 -> OutputDisksArray();
                    case 3 -> {
                        for (DiskReg disk : disks) if (!disk.DiskDebt()) disksDebt.add(disk);
                        for (int i = 0; i < disksDebt.size(); i++)
                            for (int j = i + 1; j < disksDebt.size(); j++)
                                if (disksDebt.get(i).SecondName.equals(disksDebt.get(j).SecondName) && disksDebt.get(i).Initials.equals(disksDebt.get(j).Initials)) {
                                    disksDebt.remove(j);
                                    j--;
                                }
                        OutputDisksDebtArray();
                    }
                    case 4 -> {
                        System.out.println("Введите номер диска, который хотите редактировать.");
                        if (scanner.hasNextInt()) {
                            int IndexChange = scanner.nextInt() - 1;
                            if (IndexChange >= 0 && IndexChange < disks.size()) {
                                disks.get(IndexChange).Output(IndexChange + 1);
                                System.out.println("Введите номер данных, которые хотите изменить:\n1.Фамилия\n2.Инициалы\n3.Название диска\n4.Дата выдачи\n5.Дата назначенного возврата\n6.Дата фактического возврата");
                                if (scanner.hasNextInt()) {
                                    int change = scanner.nextInt();
                                    if(change > 0 && change < 7) {
                                        disks.get(IndexChange).ChangeData(change);
                                        OutputStreamFile();
                                    }
                                    else System.out.println("Неверный номер данных.");
                                } else System.out.println("Неверный номер данных.");
                            } else System.out.println("Неверный номер.");
                        } else System.out.println("Неверный номер.");
                    }
                    case 5 -> {
                        System.out.println("Введите номер диска, который хотите удалить из списка.");
                        if (scanner.hasNextInt()) {
                            int IndexDelete = scanner.nextInt() - 1;
                            if (IndexDelete >= 0 && IndexDelete < disks.size()) {
                                disks.get(IndexDelete).Output(IndexDelete + 1);
                                System.out.println("Подтвердите удаление элемента. (Да/Нет)");
                                String consent = scanner.next();
                                if (consent.equals("Да")) {
                                    disks.remove(IndexDelete);
                                    OutputStreamFile();
                                    System.out.println("Диск удалён из списка.");
                                } else if (consent.equals("Нет")) System.out.println("Диск не будет удалён из списка.");
                                else System.out.println("Ошибка ввода подтверждения. Диск не будет удалён из списка.");
                            } else System.out.println("Неверный номер");
                        } else System.out.println("Неверный номер.");
                    }
                    case 6 -> System.exit(0);
                    default -> System.out.println("Неправильно введена комманда.");
                }
            }
            else System.out.println("Неправильно введена комманда.");
        }
    }
    private static void InputStreamFile(){
        try {
            InputStream is = new FileInputStream("G:\\My\\Proga\\Lab3-PPC\\file.bin");
            ObjectInputStream ois = new ObjectInputStream(is);
            disks = (ArrayList<DiskReg>)ois.readObject();
            ois.close();
        } catch(IOException | ClassNotFoundException e) {
            System.out.println("Невозможно прочитать файл");
            disks = new ArrayList<>();
        }
    }
    private static void OutputStreamFile(){
        try {
            OutputStream os = new FileOutputStream("G:\\My\\Proga\\Lab3-PPC\\file.bin");
            ObjectOutputStream oos = new ObjectOutputStream(os);
            //     oos.writeObject(" ");
            oos.writeObject(disks);
            oos.close();
        } catch(IOException e) {
            System.out.println("Невозможно сохранить файл");
        }
    }

    private static void OutputDisksArray(){
        if(disks.size() == 0) System.out.println("Нет зарегистрированных дисков.");
        else {
            for (int i = 0; i < disks.size(); i++) {
                disks.get(i).Output(i + 1);
            }
        }
    }
    private static void OutputDisksDebtArray(){
        if(disksDebt.size() == 0) System.out.println("Нет задолженностей.");
        else {
            for (int i = 0; i < disksDebt.size(); i++) {
                disksDebt.get(i).OutputDebt(i + 1);
            }
        }
    }

}
//Щелкунова К.В. Sims4 10.05.2021 16.11.2021 10.11.2021
//Канисский Г.Д. Монархия 12.12.2004 12.06.2005 -
//Сорокин П.А. Second_Life 23.07.2003 23.12.2003 01.01.2004
//Сорокин П.А. World_of_Warcraft 06.08.2008 06.11.2008 -