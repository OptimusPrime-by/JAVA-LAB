import java.io.Serializable;

public class Date implements Serializable {
    private int day;
    private int month;
    private int year;

    public int DataDay(){
        return day;
    }
    public int DataMonth(){
        return month;
    }
    public int DataYear(){
        return year;
    }

    public void SetDataDay(int d){
        day = d;
    }
    public void SetDataMonth(int m){
        month = m;
    }
    public void SetDataYear(int y){
        year = y;
    }

    public boolean Format(String date) {
        DateFormat form = new DateFormat();
        int[] buf = form.StringToDate(date);
        day = buf[0];
        month = buf[1];
        year = buf[2];
        return (buf[0] != -1);
    }

    public void Out() {
        DateFormat form = new DateFormat();
        String formatted = form.DateToString(day, month, year);
        if (!formatted.equals("-1")) System.out.print(formatted);
        else System.out.print("Неизвестно");
    }
}
