package Checking;

import Objects.TimeFormat;

public class Checking {
    public static boolean CheckString(String str){
        boolean test = true;
        char[] Array = str.toCharArray();
        for(int i = 0; i < Array.length; i++)
            if(!Character.isLetter(Array[i]))
                test = false;

        return test;
    }
    public static boolean CheckInitials(String str) {
        boolean test = true;
        char[] Array = str.toCharArray();
        if (Array.length == 4 && Array[1] == '.' && Array[3] == '.') {
            if (!Character.isLetter(Array[0]) || !Character.isLetter(Array[2]))
                test = false;
        } else test = false;

        return test;
    }
    public static boolean RegTalonTimeStart(TimeFormat t1, TimeFormat t2){
        int h1 = t1.DataHours(), m1 = t1.DataMinutes(), h2 = t2.DataHours(), m2 = t2.DataMinutes();
        boolean test = true;
        if(h1 > h2) test = false;
        else if(h1 == h2 && m1 > m2) test = false;
        return test; // true => t1 < t2
    }
    public static boolean CheckTimes(TimeFormat t1, TimeFormat tEnd1, TimeFormat t2, TimeFormat tEnd2){
        boolean test = true;
        if(RegTalonTimeStart(t1, t2)) {
            if(!RegTalonTimeStart(tEnd1, t2)) test = false;
        }
        else if(!RegTalonTimeStart(tEnd2, t1)) test = false;
        return test;
    }
}

