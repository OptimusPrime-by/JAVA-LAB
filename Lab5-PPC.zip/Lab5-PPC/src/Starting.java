import MainObjects.Form;

public class Starting {
    public static void main(String[] args) {
        new Form();
    }
}
