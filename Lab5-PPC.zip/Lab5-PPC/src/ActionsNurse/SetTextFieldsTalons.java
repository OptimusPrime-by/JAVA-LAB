package ActionsNurse;

import Objects.Doctor;
import Objects.Talon;
import java.util.List;

public class SetTextFieldsTalons {
    public static void SetTextFieldsTalons(ModalTalons modalTalons, Talon talon, List<Doctor> doctors){
        int index = 0;
        for(Doctor doc : doctors){
            if(doc.getID() == talon.getDoctor().getID()) modalTalons.getCB1().setSelectedIndex(index);
            index++;
        }
        modalTalons.getJT2().setText(talon.getTimeStart());
        modalTalons.getJT3H().setText(talon.getTimeLastingH());
        modalTalons.getJT3M().setText(talon.getTimeLastingM());
        modalTalons.getChB4().setSelected(talon.getActive());
        if(talon.getActive()) {
            modalTalons.getJT5().setText(talon.getSurnamePatient());
            modalTalons.getJT6().setText(talon.getInitialsPatient());
        }
        modalTalons.getJT5().setEditable(talon.getActive());
        modalTalons.getJT6().setEditable(talon.getActive());
    }
}