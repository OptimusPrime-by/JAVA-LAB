package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class ActionAddWithDoctorButton implements ActionListener {
    private JTextField JT1, JT2, JT3, JT4, JT6, JT7, JT8, JT9;
    private JCheckBox CB5;
    private Nurse nurse;
    private List<Doctor> doctors;

    public ActionAddWithDoctorButton(JTextField JT1, JTextField JT2, JTextField JT3, JTextField JT4, JCheckBox CB5, JTextField JT6, JTextField JT7,
                                     JTextField JT8, JTextField JT9, List<Doctor> doctors, Nurse nurse) {
        this.JT1 = JT1;
        this.JT2 = JT2;
        this.JT3 = JT3;
        this.JT4 = JT4;
        this.CB5 = CB5;
        this.JT6 = JT6;
        this.JT7 = JT7;
        this.JT8 = JT8;
        this.JT9 = JT9;
        this.doctors = doctors;
        this.nurse = nurse;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Вычисление неиспользованного ID врача
        int ID = 1;
        boolean flag1 = true, flag2 = true;
        while (flag1) {
            for (Doctor doc : doctors) {
                if (doc.getID() == ID) flag2 = false;
            }
            if (flag2) flag1 = false;
            else {
                ID++;
                flag2 = true;
            }
        }
        Doctor doctor = new Doctor();
        boolean test = doctor.DoctorInput(JT1.getText(), JT2.getText(), JT3.getText(), JT4.getText(), CB5.isSelected(), JT6.getText(), JT7.getText(), JT8.getText(), JT9.getText(), ID);
        if(test) {
            doctors.add(doctor);
            nurse.setDoctors(doctors);
            nurse.writeDoctorsList();
            nurse.setVisible(false);
            new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
        }
        else JOptionPane.showMessageDialog(nurse,"Ошибка в формате регистрации");
    }
}
