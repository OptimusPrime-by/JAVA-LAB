package ActionsNurse;

import Checking.Checking;
import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeWithTalonButton implements ActionListener{
    private JTextField JT2, JT3H, JT3M, JT5, JT6;
    private JComboBox CB1;
    private JCheckBox ChB4;
    private Nurse nurse;
    private JComboBox comboBox;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionChangeWithTalonButton(JComboBox CB1, JTextField JT2, JTextField JT3H, JTextField JT3M, JCheckBox ChB4, JTextField JT5, JTextField JT6, JComboBox comboBox, List<Talon> talons, List<Doctor> doctors, Nurse nurse) {
        this.CB1 = CB1;
        this.JT2 = JT2;
        this.JT3H = JT3H;
        this.JT3M = JT3M;
        this.ChB4 = ChB4;
        this.JT5 = JT5;
        this.JT6 = JT6;
        this.comboBox = comboBox;
        this.doctors = doctors;
        this.talons = talons;
        this.nurse = nurse;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Talon talon = talons.get(comboBox.getSelectedIndex());
        Talon buffer = new Talon();
        if(buffer.TalonInput(doctors.get(CB1.getSelectedIndex()), JT2.getText(), JT3H.getText(), JT3M.getText(), ChB4.isSelected(), JT5.getText(), JT6.getText(), 1)) {
            Object[] options = {"Да", "Нет", "Отмена"};
            int answer = JOptionPane.showOptionDialog(nurse, "Подтвердите изменения", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (answer == 0) {
                if (buffer.getDoctor().ChangeTalon(Integer.parseInt(talon.getTimeLastingH()), Integer.parseInt(talon.getTimeLastingM()), Integer.parseInt(buffer.getTimeLastingH()), Integer.parseInt(buffer.getTimeLastingM()), talon.getActive(), ChB4.isSelected())) {
                    boolean test1 = true;
                    for (Talon t : talons) {
                        if (!Checking.CheckTimes(t.getTimeStartFormat(), t.getTimeEndFormat(), talon.getTimeStartFormat(), talon.getTimeEndFormat()))
                            test1 = false;
                    }
                    if (test1) {
                        talon.TalonInput(doctors.get(CB1.getSelectedIndex()), JT2.getText(), JT3H.getText(), JT3M.getText(), ChB4.isSelected(), JT5.getText(), JT6.getText(), talon.getID());
                        nurse.setTalons(talons);
                        nurse.writeTalonsList();
                        nurse.setDoctors(doctors);
                        nurse.writeDoctorsList();
                        nurse.setVisible(false);
                        new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
                    }
                    else JOptionPane.showMessageDialog(nurse,"Время уже занято");
                }
                else JOptionPane.showMessageDialog(nurse,"Ошибка в формате времени изменения");
            }
            if (answer == 1) {
                nurse.setVisible(false);
                new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
            }
        }
        else {
            JOptionPane.showMessageDialog(nurse, "Ошибка в формате изменения");
        }
    }
}