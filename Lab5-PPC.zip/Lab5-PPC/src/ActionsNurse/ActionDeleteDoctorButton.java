package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionDeleteDoctorButton implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionDeleteDoctorButton(Nurse nurse, List<Doctor> doctors, List<Talon> talons){
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        JDialog dialog = new JDialog(nurse, true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new FlowLayout(FlowLayout.CENTER));
        dialog.setSize(300, 300);
        String[] items = new String[doctors.size()];
        for (int i = 0; i < doctors.size(); i++) {
            items[i] = doctors.get(i).DoctorViewTalon();

        }
        JComboBox comboBox = new JComboBox(items);
        JButton button = new JButton();
        button.setText("Удалить врача");
        button.addActionListener(new ActionDeleteWithDoctorButton(nurse, comboBox, doctors, talons));
        dialog.add(button);
        dialog.add(comboBox);
        dialog.setVisible(true);
    }
}
