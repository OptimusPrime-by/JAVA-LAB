package ActionsNurse;

import Checking.Checking;
import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


public class ActionAddWithTalonButton implements ActionListener {
    private JTextField JT2, JT3H, JT3M, JT5, JT6;
    private JComboBox CB1;
    private JCheckBox ChB4;
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionAddWithTalonButton(JComboBox CB1, JTextField JT2, JTextField JT3H, JTextField JT3M, JCheckBox ChB4, JTextField JT5, JTextField JT6, List<Talon> talons, List<Doctor> doctors, Nurse nurse) {
        this.CB1 = CB1;
        this.JT2 = JT2;
        this.JT3H = JT3H;
        this.JT3M = JT3M;
        this.ChB4 = ChB4;
        this.JT5 = JT5;
        this.JT6 = JT6;
        this.doctors = doctors;
        this.talons = talons;
        this.nurse = nurse;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Вычисление неиспользованного ID талона
        int ID = 1;
        boolean flag1 = true, flag2 = true;
        while (flag1) {
            for (Talon tal : talons) {
                if (tal.getID() == ID) flag2 = false;
            }
            if (flag2) flag1 = false;
            else {
                ID++;
                flag2 = true;
            }
        }
        Talon talon = new Talon();
        boolean test = talon.TalonInput(doctors.get(CB1.getSelectedIndex()), JT2.getText(), JT3H.getText(), JT3M.getText(), ChB4.isSelected(), JT5.getText(), JT6.getText(), ID);
        if(test) {
            if(doctors.get(CB1.getSelectedIndex()).RegisterTalon(Integer.parseInt(talon.getTimeLastingH()), Integer.parseInt(talon.getTimeLastingM()), ChB4.isSelected())) {
                boolean test1 = true;
                for (Talon t : talons) {
                    if (!Checking.CheckTimes(t.getTimeStartFormat(), t.getTimeEndFormat(), talon.getTimeStartFormat(), talon.getTimeEndFormat()))
                        test1 = false;
                }
                if (test1) {
                    talons.add(talon);
                    nurse.setTalons(talons);
                    nurse.writeTalonsList();
                    nurse.setDoctors(doctors);
                    nurse.writeDoctorsList();
                    nurse.setVisible(false);
                    new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
                }
                else JOptionPane.showMessageDialog(nurse,"Время уже занято");
            }
            else JOptionPane.showMessageDialog(nurse,"Ошибка в формате времени регистрации");
        }
        else JOptionPane.showMessageDialog(nurse,"Ошибка в формате регистрации");
    }
}