package ActionsNurse;

import MainObjects.Nurse;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ModalDoctors {
    private JDialog dialog;
    private Nurse nurse;
    private JTextField JT1, JT2, JT3, JT4, JT6, JT7, JT8, JT9;
    private JCheckBox CB5;
    private JButton button;

    public ModalDoctors(Nurse nurse){
        this.nurse = nurse;
        dialog = new JDialog(nurse, true);
        button = new JButton("");
        JT1 = new JTextField("");
        JT2 = new JTextField("");
        JT3 = new JTextField("");
        JT4 = new JTextField("");
        CB5 = new JCheckBox();
        JT6 = new JTextField("");
        JT6.setEditable(false);
        CB5.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                JT6.setEditable(CB5.isSelected());
                if(!CB5.isSelected()) JT6.setText("");
            }
        });
        JT7 = new JTextField("");
        JT8 = new JTextField("");
        JT9 = new JTextField("");
    }

    public JDialog getDialog() {
        return dialog;
    }

    public void setDialog(JDialog dialog) {
        this.dialog = dialog;
    }

    public Nurse getNurse() {
        return nurse;
    }

    public void setNurse(Nurse nurse) {
        this.nurse = nurse;
    }

    public JTextField getJT1() {
        return JT1;
    }

    public JTextField getJT2() {
        return JT2;
    }

    public JTextField getJT3() {
        return JT3;
    }

    public JTextField getJT4() {
        return JT4;
    }

    public JCheckBox getCB5() {
        return CB5;
    }

    public JTextField getJT6() {
        return JT6;
    }

    public JTextField getJT7() {
        return JT7;
    }

    public JTextField getJT8() {
        return JT8;
    }

    public JTextField getJT9() {
        return JT9;
    }

    public JButton getButton() {
        return button;
    }

    public void setButton(JButton button) {
        this.button = button;
    }

    public void ModalForm(){
        dialog.setSize(600, 380);
        dialog.setLayout(new GridLayout(11, 2, 2, 5));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JLabel SpecialityJLabel = new JLabel("Специальность");
        JLabel SurnameLabel = new JLabel("Фамилия");
        JLabel NameLabel = new JLabel("Имя");
        JLabel MiddleNameLabel = new JLabel("Отчество");
        JLabel FlagSpecialityLabel = new JLabel("Широкая направленность");
        JLabel LocalityLabel = new JLabel("Участок(только для широкой специальности)");
        JLabel CabinetLabel = new JLabel("Кабинет");
        JLabel ReceptionStartLabel = new JLabel("Начало приёма");
        JLabel ReceptionEndLabel = new JLabel("Окончание приёма");

        dialog.add(SpecialityJLabel);
        dialog.add(JT1);
        dialog.add(SurnameLabel);
        dialog.add(JT2);
        dialog.add(NameLabel);
        dialog.add(JT3);
        dialog.add(MiddleNameLabel);
        dialog.add(JT4);
        dialog.add(FlagSpecialityLabel);
        dialog.add(CB5);
        dialog.add(LocalityLabel);
        dialog.add(JT6);
        dialog.add(CabinetLabel);
        dialog.add(JT7);
        dialog.add(ReceptionStartLabel);
        dialog.add(JT8);
        dialog.add(ReceptionEndLabel);
        dialog.add(JT9);
        dialog.add(button);
        dialog.setVisible(true);
    }

}