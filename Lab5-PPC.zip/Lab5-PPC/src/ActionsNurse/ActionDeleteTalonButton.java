package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionDeleteTalonButton implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionDeleteTalonButton(Nurse nurse, List<Doctor> doctors, List<Talon> talons){
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        JDialog dialog = new JDialog(nurse, true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new FlowLayout(FlowLayout.CENTER));
        dialog.setSize(300, 300);
        String[] items = new String[talons.size()];
        for (int i = 0; i < talons.size(); i++) {
            items[i] = talons.get(i).TalonViewDoctor();

        }
        JComboBox comboBox = new JComboBox(items);
        JButton button = new JButton();
        button.setText("Удалить талон");
        button.addActionListener(new ActionDeleteWithTalonButton(nurse, comboBox, doctors, talons));
        dialog.add(button);
        dialog.add(comboBox);
        dialog.setVisible(true);
    }
}