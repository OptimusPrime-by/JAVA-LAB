package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionAddDoctorButton  implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    public ActionAddDoctorButton(Nurse nurse, List<Doctor> doctors){
        this.nurse = nurse;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        ModalDoctors modalDoctors = new ModalDoctors(nurse);
        JDialog dialog = modalDoctors.getDialog();
        JButton button = modalDoctors.getButton();
        button.addActionListener(new ActionAddWithDoctorButton(modalDoctors.getJT1(), modalDoctors.getJT2(), modalDoctors.getJT3(),
                modalDoctors.getJT4(), modalDoctors.getCB5(), modalDoctors.getJT6(), modalDoctors.getJT7(), modalDoctors.getJT8(), modalDoctors.getJT9(), doctors, nurse));
        button.setText("Добавить врача");
        modalDoctors.setButton(button);
        modalDoctors.setDialog(dialog);
        modalDoctors.ModalForm();
    }
}
