package ActionsNurse;

import Objects.Doctor;

public class SetTextFieldsDoctors {
    public static void SetTextFieldsDoctors(ModalDoctors modalDoctors, Doctor doctor){
        modalDoctors.getJT1().setText(doctor.getSpeciality());
        modalDoctors.getJT2().setText(doctor.getSurname());
        modalDoctors.getJT3().setText(doctor.getName());
        modalDoctors.getJT4().setText(doctor.getMiddleName());
        modalDoctors.getCB5().setSelected(doctor.getFlagSpeciality());
        if(doctor.getFlagSpeciality()) {
            modalDoctors.getJT6().setText(doctor.getLocality());
        }
        modalDoctors.getJT6().setEditable(doctor.getFlagSpeciality());
        modalDoctors.getJT7().setText(doctor.getCabinet());
        modalDoctors.getJT8().setText(doctor.getReceptionStartTime());
        modalDoctors.getJT9().setText(doctor.getReceptionEndTime());
    }
}
