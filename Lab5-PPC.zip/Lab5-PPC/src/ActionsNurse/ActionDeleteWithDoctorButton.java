package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionDeleteWithDoctorButton implements ActionListener {
    private Nurse nurse;
    private JComboBox comboBox;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionDeleteWithDoctorButton(Nurse nurse, JComboBox comboBox, List<Doctor> doctors, List<Talon> talons) {
        this.comboBox = comboBox;
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Doctor doctor = doctors.get(comboBox.getSelectedIndex());
        Object[] options = {"Да", "Нет", "Отмена"};
        int answer = JOptionPane.showOptionDialog(nurse, "Подтвердите удаление", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (answer == 0) {
            for(Talon t: talons){
                if(t.getDoctor().getID() == doctor.getID()) talons.remove(talons.indexOf(t));
            }
            doctors.remove(doctors.indexOf(doctor));
            nurse.setTalons(talons);
            nurse.writeTalonsList();
            nurse.setDoctors(doctors);
            nurse.writeDoctorsList();
            nurse.setVisible(false);
            new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
        }
        if (answer == 1) {
            nurse.setVisible(false);
            new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
        }
    }
}