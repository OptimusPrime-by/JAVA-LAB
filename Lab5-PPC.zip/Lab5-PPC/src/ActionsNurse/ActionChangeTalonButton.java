package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeTalonButton implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionChangeTalonButton(Nurse nurse, List<Doctor> doctors, List<Talon> talons) {
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ModalTalons modalTalons = new ModalTalons(nurse);
        String[] items = new String[talons.size()];
        for (int i = 0; i < talons.size(); i++) {
            items[i] = talons.get(i).TalonViewDoctor();

        }
        JComboBox comboBox = new JComboBox(items);
        SetTextFieldsTalons.SetTextFieldsTalons(modalTalons, talons.get(comboBox.getSelectedIndex()), doctors);
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SetTextFieldsTalons.SetTextFieldsTalons(modalTalons, talons.get(comboBox.getSelectedIndex()), doctors);
            }
        });
        JButton button = modalTalons.getButton();
        button.setText("Изменить талон");
        button.addActionListener(new ActionChangeWithTalonButton(modalTalons.getCB1(), modalTalons.getJT2(), modalTalons.getJT3H(),
                modalTalons.getJT3M(), modalTalons.getChB4(), modalTalons.getJT5(), modalTalons.getJT6(), comboBox, talons, doctors, nurse));
        modalTalons.getDialog().add(button);
        modalTalons.getDialog().add(new Label("Талоны:"));
        modalTalons.getDialog().add(comboBox);
        modalTalons.ModalForm();
    }
}