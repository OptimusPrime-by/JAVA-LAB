package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeDoctorButton implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;

    public ActionChangeDoctorButton(Nurse nurse, List<Doctor> doctors, List<Talon> talons){
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        ModalDoctors modalDoctors = new ModalDoctors(nurse);
        String[] items = new String[doctors.size()];
        for (int i = 0; i < doctors.size(); i++) {
            items[i] = doctors.get(i).DoctorViewTalon();

        }
        JComboBox comboBox = new JComboBox(items);
        SetTextFieldsDoctors.SetTextFieldsDoctors(modalDoctors, doctors.get(comboBox.getSelectedIndex()));
        comboBox.addActionListener( new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                SetTextFieldsDoctors.SetTextFieldsDoctors(modalDoctors, doctors.get(comboBox.getSelectedIndex()));
            }
        });
        JButton button = modalDoctors.getButton();
        button.setText("Изменить врача");
        button.addActionListener(new ActionChangeWithDoctorButton(modalDoctors.getJT1(), modalDoctors.getJT2(), modalDoctors.getJT3(),
                modalDoctors.getJT4(), modalDoctors.getCB5(), modalDoctors.getJT6(), modalDoctors.getJT7(), modalDoctors.getJT8(), modalDoctors.getJT9(), nurse, comboBox, doctors, talons));
        modalDoctors.getDialog().add(button);
        modalDoctors.getDialog().add(new Label("Врачи:"));
        modalDoctors.getDialog().add(comboBox);
        modalDoctors.ModalForm();
    }
}
