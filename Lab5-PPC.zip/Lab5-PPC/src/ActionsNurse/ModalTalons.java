package ActionsNurse;

import MainObjects.Nurse;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ModalTalons {
    private JDialog dialog;
    private Nurse nurse;
    private JTextField JT2, JT3H, JT3M, JT5, JT6;
    private JComboBox CB1;
    private JCheckBox ChB4;
    private JButton button;

    public ModalTalons(Nurse nurse) {
        this.nurse = nurse;
        dialog = new JDialog(nurse, true);
        button = new JButton("");
        String[] items = new String[nurse.getDoctors().size()];
        for (int i = 0; i < nurse.getDoctors().size(); i++) {
            items[i] = nurse.getDoctors().get(i).DoctorViewTalon();

        }
        CB1 = new JComboBox(items);
        JT2 = new JTextField("");
        JT3H = new JTextField("0");
        JT3M = new JTextField("0");
        ChB4 = new JCheckBox("");
        JT5 = new JTextField("");
        JT6 = new JTextField("");
        JT5.setEditable(false);
        JT6.setEditable(false);
        ChB4.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                JT5.setEditable(ChB4.isSelected());
                if (!ChB4.isSelected()) JT5.setText("");
                JT6.setEditable(ChB4.isSelected());
                if (!ChB4.isSelected()) JT6.setText("");
            }
        });
    }

    public JDialog getDialog() {
        return dialog;
    }

    public void setDialog(JDialog dialog) {
        this.dialog = dialog;
    }

    public Nurse getNurse() {
        return nurse;
    }

    public void setNurse(Nurse nurse) {
        this.nurse = nurse;
    }

    public JComboBox getCB1() {
        return CB1;
    }

    public JTextField getJT2() {
        return JT2;
    }

    public JTextField getJT3H() {
        return JT3H;
    }

    public JTextField getJT3M() {
        return JT3M;
    }

    public JCheckBox getChB4() {
        return ChB4;
    }

    public JTextField getJT5() {
        return JT5;
    }

    public JTextField getJT6() {
        return JT6;
    }

    public JButton getButton() {
        return button;
    }

    public void setButton(JButton button) {
        this.button = button;
    }

    public void ModalForm() {
        dialog.setSize(600, 340);
        dialog.setLayout(new GridLayout(8, 2, 2, 5));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JLabel DoctorJLabel = new JLabel("Врач");
        JLabel TimeStartLabel = new JLabel("Время начала приёма по талону");
        JLabel TimeLastingLabel = new JLabel("Длительность приёма");
        JLabel TimeLastingLabelH = new JLabel("ч.");
        JLabel TimeLastingLabelM = new JLabel("м.");
        JLabel ActiveLabel = new JLabel("Талон выдан");
        JLabel SurnamePatientLabel = new JLabel("Фамилия пользователя(если талон выдан)");
        JLabel InitialsPatientLabel = new JLabel("Инициалы пользователя(если талон выдан)");

        dialog.add(DoctorJLabel);
        dialog.add(CB1);
        dialog.add(TimeStartLabel);
        dialog.add(JT2);
        dialog.add(TimeLastingLabel);
        JPanel panelTime = new JPanel(new GridLayout(1, 4, 1, 5));
        panelTime.add(JT3H);
        panelTime.add(TimeLastingLabelH);
        panelTime.add(JT3M);
        panelTime.add(TimeLastingLabelM);
        dialog.add(panelTime);
        dialog.add(ActiveLabel);
        dialog.add(ChB4);
        dialog.add(SurnamePatientLabel);
        dialog.add(JT5);
        dialog.add(InitialsPatientLabel);
        dialog.add(JT6);
        dialog.add(button);
        dialog.setVisible(true);
    }

}