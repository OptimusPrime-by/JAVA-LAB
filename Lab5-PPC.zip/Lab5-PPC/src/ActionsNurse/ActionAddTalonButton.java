package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionAddTalonButton  implements ActionListener {
    private Nurse nurse;
    private List<Doctor> doctors;
    private List<Talon> talons;
    public ActionAddTalonButton(Nurse nurse, List<Doctor> doctors, List<Talon> talons){
        this.nurse = nurse;
        this.doctors = doctors;
        this.talons = talons;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        ModalTalons modalTalons = new ModalTalons(nurse);
        JDialog dialog = modalTalons.getDialog();
        JButton button = modalTalons.getButton();
        button.addActionListener(new ActionAddWithTalonButton(modalTalons.getCB1(), modalTalons.getJT2(), modalTalons.getJT3H(),
                modalTalons.getJT3M(), modalTalons.getChB4(), modalTalons.getJT5(), modalTalons.getJT6(), talons, doctors, nurse));
        button.setText("Добавить талон");
        modalTalons.setButton(button);
        modalTalons.setDialog(dialog);
        modalTalons.ModalForm();
    }
}
