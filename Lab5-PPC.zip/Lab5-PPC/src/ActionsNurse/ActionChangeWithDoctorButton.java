package ActionsNurse;

import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeWithDoctorButton implements ActionListener{
    private JTextField JT1, JT2, JT3, JT4, JT6, JT7, JT8, JT9;
    private JCheckBox CB5;
    private Nurse nurse;
    private List<Talon> talons;
    private JComboBox comboBox;
    private List<Doctor> doctors;

    public ActionChangeWithDoctorButton(JTextField JT1, JTextField JT2, JTextField JT3, JTextField JT4, JCheckBox CB5, JTextField JT6, JTextField JT7,
                                     JTextField JT8, JTextField JT9, Nurse nurse, JComboBox comboBox, List<Doctor> doctors, List<Talon> talons) {
        this.JT1 = JT1;
        this.JT2 = JT2;
        this.JT3 = JT3;
        this.JT4 = JT4;
        this.CB5 = CB5;
        this.JT6 = JT6;
        this.JT7 = JT7;
        this.JT8 = JT8;
        this.JT9 = JT9;
        this.comboBox = comboBox;
        this.nurse = nurse;
        this.talons = talons;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Doctor doctor = doctors.get(comboBox.getSelectedIndex());
        Doctor buffer = new Doctor();
        if(buffer.DoctorInput(JT1.getText(), JT2.getText(), JT3.getText(), JT4.getText(), CB5.isSelected(), JT6.getText(), JT7.getText(), JT8.getText(), JT9.getText(), 1)){
            Object[] options = {"Да", "Нет", "Отмена"};
            int answer = JOptionPane.showOptionDialog(nurse, "Подтвердите изменения", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if(answer == 0){
                doctor.DoctorInput(JT1.getText(), JT2.getText(), JT3.getText(), JT4.getText(), CB5.isSelected(), JT6.getText(), JT7.getText(), JT8.getText(), JT9.getText(), doctor.getID());
                for(Talon t: talons){
                    if(t.getDoctor().getID() == doctor.getID()) {
                        if (!buffer.RegisterTalon(Integer.parseInt(t.getTimeLastingH()), Integer.parseInt(t.getTimeLastingM()), false)) {
                            doctor.DeleteTalon(Integer.parseInt(t.getTimeLastingH()), Integer.parseInt(t.getTimeLastingM()), t.getActive());
                            talons.remove(talons.indexOf(t));
                        }
                    }
                }
                nurse.setTalons(talons);
                nurse.writeTalonsList();
                nurse.setDoctors(doctors);
                nurse.writeDoctorsList();
                nurse.setVisible(false);
                new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
            }
            if(answer == 1){
                nurse.setVisible(false);
                new Nurse(nurse.GetNameUser(), nurse.GetSurnameUser(), nurse.GetIDUser());
            }
        }
        else {
            JOptionPane.showMessageDialog(nurse, "Ошибка в формате изменения");
        }
    }
}
