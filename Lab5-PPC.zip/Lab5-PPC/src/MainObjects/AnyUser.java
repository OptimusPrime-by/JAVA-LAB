package MainObjects;

import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import ActionsAnyUser.*;

public class AnyUser extends JFrame {
    private List<Doctor> doctors = new ArrayList<>();
    private List<Talon> talons = new ArrayList<>();
    private List<String> listUsers;

    public List<Doctor> getDoctors() {
        return doctors;
    }

    public void setDoctors(List<Doctor> doctors) {
        this.doctors = doctors;
    }

    public List<Talon> getTalons() {
        return talons;
    }

    public void setTalons(List<Talon> talons) {
        this.talons = talons;
    }

    public List<String> getListUsers() {
        return listUsers;
    }

    public void setListUsers(List<String> listUsers) {
        this.listUsers = listUsers;
    }

    public AnyUser() {
        super();
        this.readTalonsList();
        this.readDoctorsList();
        this.readUsersList();
        setLayout(null);
        setBounds(100, 100, 640, 240);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER));
        String[] items = new String[doctors.size()];
        for (int i = 0; i < doctors.size(); i++) {
            items[i] = doctors.get(i).DoctorViewTalon();

        }
        JComboBox comboBox = new JComboBox(items);
        add(comboBox);
        JButton showTableDoctor = new JButton("База данных врачей");
        showTableDoctor.addActionListener(new ActionWithTableDoctorButton(doctors, this));
        add(showTableDoctor);
        JButton showTableTalon = new JButton("База данных талонов");
        showTableTalon.addActionListener(new ActionWithTableTalonButton(talons, comboBox, this, doctors));
        add(showTableTalon);
        setVisible(true);

    }

    public void readTalonsList() {
        try {
            InputStream inputStream = new FileInputStream("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListTalons.bin");
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            talons.clear();
            talons = (List<Talon>)objectInputStream.readObject();

            objectInputStream.close();
        }
        catch (IOException e) {
            writeTalonsList();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void writeTalonsList() {
        try {
            OutputStream outputStream = new FileOutputStream("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListTalons.bin");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(talons);
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readDoctorsList() {
        try {
            InputStream inputStream = new FileInputStream("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListDoctors.bin");
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            doctors.clear();
            doctors = (List<Doctor>)objectInputStream.readObject();
            objectInputStream.close();
        } catch (IOException e) {
            writeDoctorsList();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void writeDoctorsList() {
        try {
            OutputStream outputStream = new FileOutputStream("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListDoctors.bin");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(doctors);
            objectOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void readUsersList() {
        try {
            FileReader fr = new FileReader("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListUsers.txt");
            BufferedReader buf = new BufferedReader(fr);
            listUsers = new ArrayList<>();
            String str = buf.readLine();
            while (str != null) {
                listUsers.add(str);
                str = buf.readLine();
            }
            fr.close();
            buf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeUsersList() {
        try {
            FileWriter fw = new FileWriter("G:\\My\\Proga\\Lab5-PPC\\Lab5-PPC\\src\\ListUsers.txt");
            PrintWriter wf = new PrintWriter(fw);

            for (String str : this.listUsers) {
                wf.println(str);
            }
            wf.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
