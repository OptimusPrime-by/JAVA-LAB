package MainObjects;

import ActionsNurse.*;
import Objects.Talon;
import Objects.Doctor;

import javax.swing.*;
import java.util.List;

public class Nurse extends AuthorizationUser{
    private JMenuBar Menu;

    public Nurse(String name, String surname, int id) {
        super(name, surname, id);
        this.Menu = this.getMenuUser();
        JLabel NurseLabel = new JLabel("    Медсестра");
        Menu.add(NurseLabel);
        List<Doctor> doctors = getDoctors();
        List<Talon> talons = getTalons();
        JButton addDoctor = new JButton("Добавить врача");
        addDoctor.addActionListener(new ActionAddDoctorButton(this, doctors));
        add(addDoctor);
        JButton changeDoctor = new JButton("Изменить врача");
        changeDoctor.addActionListener(new ActionChangeDoctorButton(this, doctors, talons));
        changeDoctor.setEnabled(doctors.size() != 0);
        add(changeDoctor);
        JButton deleteDoctor = new JButton("Удалить врача");
        deleteDoctor.addActionListener( new ActionDeleteDoctorButton(this, doctors, talons));
        deleteDoctor.setEnabled(doctors.size() != 0);
        add(deleteDoctor);
        JButton addTalon = new JButton("Добавить талон");
        addTalon.addActionListener(new ActionAddTalonButton(this, doctors, talons));
        addTalon.setEnabled(doctors.size() != 0);
        add(addTalon);
        JButton changeTalon = new JButton("Изменить талон");
        changeTalon.addActionListener(new ActionChangeTalonButton(this, doctors, talons));
        changeTalon.setEnabled(talons.size() != 0);
        add(changeTalon);
        JButton deleteTalon = new JButton("Удалить талон");
        deleteTalon.addActionListener(new ActionDeleteTalonButton(this, doctors, talons));
        deleteTalon.setEnabled(talons.size() != 0);
        add(deleteTalon);
        this.validate();
        this.setVisible(true);
    }
}
