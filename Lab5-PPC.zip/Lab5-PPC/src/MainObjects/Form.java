package MainObjects;
import ActionsAnyUser.ActionWithLogInButton;
import ActionsAnyUser.ActionWithRegistrationButton;

import javax.swing.*;

public class Form extends AnyUser{
    private JButton RegistrationButton;
    private JButton LogInButton;
    private JMenuBar menu;

    public JButton getLogInButton() {
        return LogInButton;
    }
    public JButton getRegistrationButton(){
        return RegistrationButton;
    }
    public JMenuBar getMenuUser() {return menu;}
    public Form(){
        super();
        menu = new JMenuBar();
        RegistrationButton = new JButton("Зарегистрироваться");
        RegistrationButton.addActionListener(new ActionWithRegistrationButton(this));
        menu.add(RegistrationButton);
        LogInButton = new JButton("Войти");
        LogInButton.addActionListener(new ActionWithLogInButton(this));
        menu.add(LogInButton);
        setJMenuBar(menu);

        validate();
        setVisible(true);
    }
}
