package MainObjects;

import ActionsAdmin.*;
import ActionsNurse.ActionAddDoctorButton;

import javax.swing.*;

public class Admin extends AuthorizationUser{
    private JMenuBar Menu;

    public Admin(String name, String surname, int id) {
        super(name, surname, id);
        this.Menu = this.getMenuUser();
        JLabel AdminLabel = new JLabel("    Админ");
        Menu.add(AdminLabel);
        JButton checkTableUsers = new JButton("Просмотр списка пользователей");
        checkTableUsers.addActionListener(new ActionWithTableUserButton(this.getListUsers(), this));
        add(checkTableUsers);
        JButton addUser = new JButton("Добавить пользователя");
        addUser.addActionListener(new ActionAddUserButton(this, this.getListUsers()));
        add(addUser);
        JButton changeUser = new JButton("Изменить пользователя");
        changeUser.addActionListener(new ActionChangeUserButton(this, this.getListUsers()));
        changeUser.setEnabled(this.getListUsers().size() != 0);
        add(changeUser);
        JButton deleteUser = new JButton("Удалить пользователя");
        deleteUser.addActionListener(new ActionDeleteUserButton(this, this.getListUsers()));
        deleteUser.setEnabled(this.getListUsers().size() != 0);
        add(deleteUser);
        this.validate();
        this.setVisible(true);
    }
}
