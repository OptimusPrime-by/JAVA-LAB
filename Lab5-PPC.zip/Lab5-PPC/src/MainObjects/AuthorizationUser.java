package MainObjects;

import javax.swing.*;
import ActionsAnyUser.LogOutActionButton;

public class AuthorizationUser extends Form{
    private String Name;
    private String Surname;
    private int ID;
    private JMenuBar Menu;

    public String GetNameUser() { return this.Name;}
    public String GetSurnameUser() { return this.Surname;}
    public int GetIDUser() { return this.ID;}

    public void SetNameUser(String name){this.Name = name;}
    public void SetSurnameUser(String surname){this.Surname = surname;}
    public void SetIDUser(int id){this.ID = id;}

    public AuthorizationUser(String name, String surname, int id){
        super();
        this.Name = name;
        this.Surname = surname;
        this.ID = id;
        this.Menu = this.getMenuUser();

        Menu.remove(this.getLogInButton());
        Menu.remove(this.getRegistrationButton());
        JButton logOut = new JButton("Выйти");
        Menu.add(logOut);
        logOut.addActionListener(new LogOutActionButton(this));
        JLabel LabelName = new JLabel(" " + Name);
        JLabel LabelSurname = new JLabel(" " + Surname);
        Menu.add(LabelName);
        Menu.add(LabelSurname);
    }
}
