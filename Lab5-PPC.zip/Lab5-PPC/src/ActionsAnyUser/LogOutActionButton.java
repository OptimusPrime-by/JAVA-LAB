package ActionsAnyUser;

import MainObjects.AuthorizationUser;
import MainObjects.Form;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogOutActionButton implements ActionListener {
    AuthorizationUser au;

    public LogOutActionButton(AuthorizationUser au) {
        this.au = au;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        au.setVisible(false);
        Form form = new Form();

    }
}