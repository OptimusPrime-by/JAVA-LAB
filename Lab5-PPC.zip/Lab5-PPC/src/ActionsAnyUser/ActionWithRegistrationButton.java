package ActionsAnyUser;

import MainObjects.Form;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ActionWithRegistrationButton implements ActionListener{
    private Form form;

    public ActionWithRegistrationButton(Form form){
        this.form = form;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        JDialog dialog = new JDialog(form, "Регистрация", true);
        dialog.setLayout(null);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setBounds(120, 120, 600, 400);
        dialog.setLayout(new GridLayout(5,2,1,1));
        JTextField NameTF = new JTextField();
        JTextField SurnameTF = new JTextField();
        JTextField LoginTF = new JTextField();
        JTextField PasswordTF= new JTextField();
        JLabel NameLabel = new JLabel("         Имя:");
        JLabel SurnameLabel = new JLabel("         Фамилия:");
        JLabel LoginLabel = new JLabel("         Логин:");
        JLabel PasswordLabel= new JLabel("         Пароль:");
        JButton RegistrationUser = new JButton("Зарегистрироваться");
        dialog.add(NameLabel);
        dialog.add(NameTF);
        dialog.add(SurnameLabel);
        dialog.add(SurnameTF);
        dialog.add(LoginLabel);
        dialog.add(LoginTF);
        dialog.add(PasswordLabel);
        dialog.add(PasswordTF);
        RegistrationUser.addActionListener(new RegistrationActionListener(form, dialog, NameTF, SurnameTF, LoginTF, PasswordTF));
        dialog.add(RegistrationUser);

        dialog.validate();
        dialog.setVisible(true);

    }
}
