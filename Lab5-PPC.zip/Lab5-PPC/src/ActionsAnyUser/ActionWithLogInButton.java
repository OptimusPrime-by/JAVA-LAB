package ActionsAnyUser;

import MainObjects.Form;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionWithLogInButton implements ActionListener{
    private Form form;

    public ActionWithLogInButton(Form form){
        this.form = form;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        JDialog dialog = new JDialog(form, "Авторизация", true);
        dialog.setLayout(null);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setBounds(120, 120, 250, 250);
        JTextField login = new JTextField("");
        JTextField password = new JTextField();
        login.setToolTipText("Логин");
        password.setToolTipText("Пароль");
        login.setBounds(50, 50, 130, 30);
        password.setBounds(50, 95, 130, 30);
        dialog.add(login);
        dialog.add(password);
        JButton logIn = new JButton("Войти");
        logIn.setBounds(70, 135, 90, 20);
        logIn.addActionListener(new LogInActionListener(form,dialog,login,password));
        dialog.add(logIn);
        dialog.validate();
        dialog.setVisible(true);

    }
}
