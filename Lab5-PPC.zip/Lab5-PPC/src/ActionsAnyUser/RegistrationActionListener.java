package ActionsAnyUser;

import Checking.Checking;
import MainObjects.Form;
import MainObjects.AuthorizationUser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class RegistrationActionListener implements ActionListener{
    private Form form;
    private Dialog dialog;
    private JTextField name, surname, login, password;

    public RegistrationActionListener(Form form, Dialog dialog, JTextField name, JTextField surname, JTextField login, JTextField password){
        this.form = form;
        this.dialog = dialog;
        this.name = name;
        this.surname = surname;
        this.login = login;
        this.password = password;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        List<String> UsersList = form.getListUsers();
        String[] strings;
        boolean test1 = true;
        boolean test2 = true;
        if(!Checking.CheckString(name.getText())) test1 = false;
        if(!Checking.CheckString(surname.getText())) test1 = false;
        for(String str : UsersList) {
            strings = str.split("\\|");
            if(strings[3].equalsIgnoreCase(login.getText())) test2 = false;
        }
        //Вычисление неиспользованного ID пользователя
        if(test1 && test2) {
            int ID = 1;
            boolean flag1 = true, flag2 = true;
            while (flag1) {
                for (String str : UsersList) {
                    strings = str.split("\\|");
                    if (Integer.parseInt(strings[2]) == ID) flag2 = false;
                }
                if (flag2) flag1 = false;
                else {
                    ID++;
                    flag2 = true;
                }
            }
            new AuthorizationUser(name.getText(), surname.getText(), ID);
            dialog.setVisible(false);
            form.setVisible(false);
            UsersList.add(name.getText() + "|" + surname.getText() + "|" + ID + "|" + login.getText() + "|" + password.getText() + "|1");
            form.setListUsers(UsersList);
            form.writeUsersList();
        }
        if(!test1){
            JOptionPane.showMessageDialog(dialog, "Неверный ввод имени/фамилии");
        }
        if(!test2){
            JOptionPane.showMessageDialog(dialog, "Логин уже использован");
        }
    }
}
