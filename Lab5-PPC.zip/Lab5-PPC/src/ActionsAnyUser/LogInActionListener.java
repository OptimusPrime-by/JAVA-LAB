package ActionsAnyUser;

import MainObjects.Form;
import MainObjects.Admin;
import MainObjects.AuthorizationUser;
import MainObjects.Nurse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

//Вход
public class LogInActionListener implements ActionListener{
    private Form form;
    private Dialog dialog;
    private JTextField login, password;

    public LogInActionListener(Form form, Dialog dialog, JTextField login, JTextField password){
        this.form = form;
        this.dialog = dialog;
        this.login = login;
        this.password = password;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        List<String> UsersList = form.getListUsers();
        String[] strings;
        boolean flag = true;
        for(String str : UsersList) {
            strings = str.split("\\|");
            if(strings[3].equalsIgnoreCase(login.getText()) && strings[4].equalsIgnoreCase(password.getText())) {
                switch (strings[5]){
                    case "1": {
                        new AuthorizationUser(strings[0], strings[1], Integer.parseInt(strings[2]));
                        flag = false;
                        dialog.setVisible(false);
                        form.setVisible(false);
                        break;
                    }
                    case "2": {
                        new Admin(strings[0], strings[1], Integer.parseInt(strings[2]));
                        flag = false;
                        dialog.setVisible(false);
                        form.setVisible(false);
                        break;
                    }
                    case "3": {
                        new Nurse(strings[0], strings[1], Integer.parseInt(strings[2]));
                        flag = false;
                        dialog.setVisible(false);
                        form.setVisible(false);
                        break;
                    }
                }
            }
        }
        if(flag){
            JOptionPane.showMessageDialog(dialog, "Неверный логин/пароль");
        }
    }
}
