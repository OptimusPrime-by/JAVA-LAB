package ActionsAnyUser;

import javax.swing.*;
import javax.swing.table.DefaultTableModel; //реализацией TableModel
import javax.swing.table.TableModel; //модель таблицы
import javax.swing.table.TableRowSorter; //сортировка и фильтрация таблицы
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import MainObjects.AnyUser;
import Objects.Talon;
import Objects.Doctor;

public class ActionWithTableTalonButton implements ActionListener {
    private List<Talon> talons;
    private JComboBox comboBox;
    private AnyUser user;
    private List<Doctor> doctors;

    public ActionWithTableTalonButton(List<Talon> talons, JComboBox comboBox, AnyUser user, List<Doctor> doctors){
        this.talons = talons;
        this.comboBox = comboBox;
        this.user = user;
        this.doctors = doctors;
    }

    @Override
    public void actionPerformed(ActionEvent a){
        int id = 0;
        try {
            id = comboBox.getSelectedIndex();
        }
        catch (NullPointerException e) {
            e.printStackTrace();
        }
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Врач");
        tableModel.addColumn("Начало приёма по талону");
        tableModel.addColumn("Длительность приёма");
        tableModel.addColumn("Aктивность");
        tableModel.addColumn("Пациент");
        int index = 0;

        for(Talon t: talons){
            if(t.getDoctor().getID() == doctors.get(id).getID()){
                tableModel.insertRow(index, t.toString().split("\\|")); //бубуйня
                index++;
            }
        }
        JTable table = new JTable(tableModel);
        RowSorter<TableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        table.setEnabled(false);
        JDialog dialog = new JDialog(user,"База данных талонов",true);
        dialog.setSize(550,350);
        dialog.add(new JScrollPane(table));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }
}
