package ActionsAnyUser;

import javax.swing.*;
import javax.swing.table.DefaultTableModel; //реализацией TableModel
import javax.swing.table.TableModel; //модель таблицы
import javax.swing.table.TableRowSorter; //сортировка и фильтрация таблицы
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import MainObjects.AnyUser;
import Objects.Doctor;

public class ActionWithTableDoctorButton implements ActionListener {
    private List<Doctor> doctors;
    private AnyUser user;

    public ActionWithTableDoctorButton(List<Doctor> doctors, AnyUser user){
        this.doctors = doctors;
        this.user = user;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Специальность");
        tableModel.addColumn("Фамилия");
        tableModel.addColumn("Имя");
        tableModel.addColumn("Отчество");
        tableModel.addColumn("Направленность");
        tableModel.addColumn("Участок");
        tableModel.addColumn("Кабинет");
        tableModel.addColumn("Начало приёма");
        tableModel.addColumn("Окончание приёма");
        tableModel.addColumn("Количество свободных талонов");
        tableModel.addColumn("Общее время по выданным талонам");
        int Index = 0;

        for(Doctor d: doctors){
            tableModel.insertRow(Index, d.toString().split("\\|"));
            Index++;
        }
        JTable table = new JTable(tableModel);
        RowSorter<TableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        table.setEnabled(false);
        JDialog dialog = new JDialog(user, "База данных врачей", true);
        dialog.setSize(800, 300);
        dialog.add(new JScrollPane(table));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }
}
