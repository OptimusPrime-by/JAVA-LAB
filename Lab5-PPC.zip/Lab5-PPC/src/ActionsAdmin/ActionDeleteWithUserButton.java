package ActionsAdmin;

import MainObjects.Admin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionDeleteWithUserButton implements ActionListener {
    private Admin admin;
    private List<String> UsersList;
    private JComboBox comboBox;

    public ActionDeleteWithUserButton(JComboBox comboBox, List<String> UsersList, Admin admin) {
        this.UsersList = UsersList;
        this.admin = admin;
        this.comboBox = comboBox;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String[] arrSplit = UsersList.get(comboBox.getSelectedIndex()).split("\\|");
        int ID = Integer.parseInt(arrSplit[2]);
        if(ID != admin.GetIDUser()) {
            Object[] options = {"Да", "Нет", "Отмена"};
            int answer = JOptionPane.showOptionDialog(admin, "Подтвердите удаление", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (answer == 0) {
                UsersList.remove(comboBox.getSelectedIndex());
                admin.setListUsers(UsersList);
                admin.writeUsersList();
                admin.setVisible(false);
                new Admin(admin.GetNameUser(), admin.GetSurnameUser(), admin.GetIDUser());
            }
            if (answer == 1) {
                admin.setVisible(false);
                new Admin(admin.GetNameUser(), admin.GetSurnameUser(), admin.GetIDUser());
            }
        }
        else JOptionPane.showMessageDialog(admin, "Ты не можешь удалить себя, глупенький :)");
    }
}