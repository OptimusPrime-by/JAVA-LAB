package ActionsAdmin;

import MainObjects.Admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionWithTableUserButton implements ActionListener {
    private List<String> usersList;
    private Admin admin;

    public ActionWithTableUserButton(List<String> usersList, Admin admin){
        this.usersList = usersList;
        this.admin = admin;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Имя");
        tableModel.addColumn("Фамилия");
        tableModel.addColumn("ID");
        tableModel.addColumn("Логин");
        tableModel.addColumn("Пароль");
        tableModel.addColumn("Права");
        int Index = 0;
        for(String str: usersList){
            tableModel.insertRow(Index, str.toString().split("\\|"));
            Index++;
        }
        JTable table = new JTable(tableModel);
        RowSorter<TableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        table.setEnabled(false);
        JDialog dialog = new JDialog(admin, "Учётные данные", true);
        dialog.setSize(600, 200);
        dialog.add(new JScrollPane(table));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    }
}