package ActionsAdmin;

import ActionsNurse.ActionDeleteWithTalonButton;
import MainObjects.Admin;
import MainObjects.Nurse;
import Objects.Doctor;
import Objects.Talon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionDeleteUserButton implements ActionListener {
    private Admin admin;
    private List<String> UsersList;

    public ActionDeleteUserButton(Admin admin, List<String> UsersList){
        this.UsersList = UsersList;
        this.admin = admin;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        JDialog dialog = new JDialog(admin, true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setLayout(new FlowLayout(FlowLayout.CENTER));
        dialog.setSize(300, 300);
        String[] items = new String[UsersList.size()];
        int index = 0;
        for (String str : UsersList) {
            String[] arrSplit = str.split("\\|");
            items[index] = arrSplit[1] + " " + arrSplit[0] + "| ID=" + arrSplit[2];
            index++;

        }
        JComboBox comboBox = new JComboBox(items);
        JButton button = new JButton();
        button.setText("Удалить пользователя");
        button.addActionListener(new ActionDeleteWithUserButton(comboBox, UsersList, admin));
        dialog.add(button);
        dialog.add(comboBox);
        dialog.setVisible(true);
    }
}