package ActionsAdmin;

public class SetTextFieldsUsers {
    public static void SetTextFieldsUsers(ModalUsers modalUsers, String user){
        String[] arrSplit = user.split("\\|");
        modalUsers.getJT1().setText(arrSplit[0]);
        modalUsers.getJT2().setText(arrSplit[1]);
        modalUsers.getJT3().setText(arrSplit[3]);
        modalUsers.getJT4().setText(arrSplit[4]);
        modalUsers.getCB5().setSelectedIndex(Integer.parseInt(arrSplit[5])-1);
    }
}
