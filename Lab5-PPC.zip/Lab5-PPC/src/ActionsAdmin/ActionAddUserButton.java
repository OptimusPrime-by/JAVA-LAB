package ActionsAdmin;

import MainObjects.Admin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionAddUserButton implements ActionListener {
    private Admin admin;
    private List<String> UsersList;
    public ActionAddUserButton(Admin admin, List<String> UsersList){
        this.admin = admin;
        this.UsersList = UsersList;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        ModalUsers modalUsers = new ModalUsers(admin);
        JDialog dialog = modalUsers.getDialog();
        JButton button = modalUsers.getButton();
        button.addActionListener(new ActionAddWithUserButton(modalUsers.getJT1(), modalUsers.getJT2(), modalUsers.getJT3(),
                modalUsers.getJT4(), modalUsers.getCB5(), UsersList, admin));
        button.setText("Добавить пользователя");
        modalUsers.setButton(button);
        modalUsers.setDialog(dialog);
        modalUsers.ModalForm();
    }
}