package ActionsAdmin;

import MainObjects.Admin;

import javax.swing.*;
import java.awt.*;

public class ModalUsers {
    private JDialog dialog;
    private Admin admin;
    private JTextField JT1, JT2, JT3, JT4;
    private JComboBox CB5;
    private JButton button;

    public ModalUsers(Admin admin) {
        this.admin = admin;
        dialog = new JDialog(admin, true);
        button = new JButton("");
        JT1 = new JTextField("");
        JT2 = new JTextField("");
        JT3 = new JTextField("");
        JT4 = new JTextField("");
        String[] items = {"Пользователь(1)", "Админ(2)", "Медсестра(3)"};
        CB5 = new JComboBox(items);
    }

    public JDialog getDialog() {
        return dialog;
    }

    public void setDialog(JDialog dialog) {
        this.dialog = dialog;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setNurse(Admin admin) {
        this.admin = admin;
    }

    public JTextField getJT1() {
        return JT1;
    }

    public JTextField getJT2() {
        return JT2;
    }

    public JTextField getJT3() {
        return JT3;
    }

    public JTextField getJT4() {
        return JT4;
    }

    public JComboBox getCB5() {
        return CB5;
    }

    public JButton getButton() {
        return button;
    }

    public void setButton(JButton button) {
        this.button = button;
    }

    public void ModalForm() {
        dialog.setSize(600, 300);
        dialog.setLayout(new GridLayout(7, 2, 2, 5));
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JLabel NameJLabel = new JLabel("Имя пользователя");
        JLabel SurnameLabel = new JLabel("Фамилия пользователя");
        JLabel LoginLabel = new JLabel("Логин");
        JLabel PasswordLabel = new JLabel("Пароль");
        JLabel RightsLabel = new JLabel("Права");

        dialog.add(NameJLabel);
        dialog.add(JT1);
        dialog.add(SurnameLabel);
        dialog.add(JT2);
        dialog.add(LoginLabel);
        dialog.add(JT3);
        dialog.add(PasswordLabel);
        dialog.add(JT4);
        dialog.add(RightsLabel);
        dialog.add(CB5);
        dialog.add(button);
        dialog.setVisible(true);
    }
}
