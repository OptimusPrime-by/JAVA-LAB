package ActionsAdmin;


import MainObjects.Admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeUserButton implements ActionListener {
    private Admin admin;
    private List<String> UsersList;

    public ActionChangeUserButton(Admin admin, List<String> UsersList) {
        this.admin = admin;
        this.UsersList = UsersList;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ModalUsers modalUsers = new ModalUsers(admin);
        JDialog dialog = modalUsers.getDialog();
        String[] items = new String[UsersList.size()];
        int index = 0;
        for (String str : UsersList) {
            String[] arrSplit = str.split("\\|");
            items[index] = arrSplit[1] + " " + arrSplit[0] + "| ID=" + arrSplit[2];
            index++;

        }
        JComboBox comboBox = new JComboBox(items);
        SetTextFieldsUsers.SetTextFieldsUsers(modalUsers, UsersList.get(comboBox.getSelectedIndex()));
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SetTextFieldsUsers.SetTextFieldsUsers(modalUsers, UsersList.get(comboBox.getSelectedIndex()));
            }
        });
        JButton button = modalUsers.getButton();
        button.setText("Изменить пользователя");
        button.addActionListener(new ActionChangeWithUserButton(modalUsers.getJT1(), modalUsers.getJT2(), modalUsers.getJT3(),
                modalUsers.getJT4(), modalUsers.getCB5(), comboBox, UsersList, admin));
        dialog.add(button);
        dialog.add(new Label("Пользователи:"));
        dialog.add(comboBox);
        modalUsers.setDialog(dialog);
        modalUsers.ModalForm();
    }
}
