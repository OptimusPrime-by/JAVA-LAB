package ActionsAdmin;

import Checking.Checking;
import MainObjects.Admin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionAddWithUserButton implements ActionListener {
    private Admin admin;
    private JTextField JT1, JT2, JT3, JT4;
    private JComboBox CB5;
    private List<String> UsersList;

    public ActionAddWithUserButton(JTextField JT1, JTextField JT2, JTextField JT3, JTextField JT4, JComboBox CB5, List<String> UsersList, Admin admin) {
        this.JT1 = JT1;
        this.JT2 = JT2;
        this.JT3 = JT3;
        this.JT4 = JT4;
        this.CB5 = CB5;
        this.UsersList = UsersList;
        this.admin = admin;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Вычисление неиспользованного ID пользователя

        int ID = 1;
        boolean flag1 = true, flag2 = true;
        while (flag1) {
            for (String str : UsersList) {
                String[] arrSplit = str.split("\\|");
                if (Integer.parseInt(arrSplit[2]) == ID) flag2 = false;
            }
            if (flag2) flag1 = false;
            else {
                ID++;
                flag2 = true;
            }
        }
        String user;
        boolean test = !(!Checking.CheckString(JT1.getText()) ||
                !Checking.CheckString(JT2.getText()) ||
                JT3.getText().equals("") ||
                JT4.getText().equals(""));
        if (test) {
            for (String str : UsersList) {
                String[] arrSplit = str.split("\\|");
                if (arrSplit[3].equals(JT3.getText())) test = false;
            }
            if (test) {
                user = JT1.getText() + "|" + JT2.getText() + "|" + ID + "|" + JT3.getText() + "|" + JT4.getText() + "|" + (CB5.getSelectedIndex() + 1);
                UsersList.add(user);
                admin.setListUsers(UsersList);
                admin.writeUsersList();
                admin.setVisible(false);
                new Admin(admin.GetNameUser(), admin.GetSurnameUser(), admin.GetIDUser());
            } else JOptionPane.showMessageDialog(admin, "Логин уже используется");
        } else JOptionPane.showMessageDialog(admin, "Ошибка в формате регистрации");
    }
}
