package ActionsAdmin;

import Checking.Checking;
import MainObjects.Admin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ActionChangeWithUserButton implements ActionListener {
    private Admin admin;
    private JTextField JT1, JT2, JT3, JT4;
    private JComboBox CB5, comboBox;
    private List<String> UsersList;

    public ActionChangeWithUserButton(JTextField JT1, JTextField JT2, JTextField JT3, JTextField JT4, JComboBox CB5, JComboBox comboBox, List<String> UsersList, Admin admin) {
        this.JT1 = JT1;
        this.JT2 = JT2;
        this.JT3 = JT3;
        this.JT4 = JT4;
        this.CB5 = CB5;
        this.UsersList = UsersList;
        this.admin = admin;
        this.comboBox = comboBox;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String user = UsersList.get(comboBox.getSelectedIndex());
        String[] arrSplitUser = user.split("\\|");
        boolean test = !(!Checking.CheckString(JT1.getText()) ||
                !Checking.CheckString(JT2.getText()) ||
                JT3.getText().equals("") ||
                JT4.getText().equals(""));
        if (test) {
            for (String str : UsersList) {
                String[] arrSplit = str.split("\\|");
                if (arrSplit[3].equals(JT3.getText()) && !arrSplit[2].equals(arrSplitUser[2])) test = false;
            }
            if (test) {
                int ID = Integer.parseInt(arrSplitUser[2]);
                if (ID != admin.GetIDUser() || ID == admin.GetIDUser() && (CB5.getSelectedIndex() + 1) == 2) {
                    Object[] options = {"Да", "Нет", "Отмена"};
                    int answer = JOptionPane.showOptionDialog(admin, "Подтвердите изменения", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                    if (answer == 0) {

                        user = JT1.getText() + "|" + JT2.getText() + "|" + ID + "|" + JT3.getText() + "|" + JT4.getText() + "|" + (CB5.getSelectedIndex() + 1);
                        int index = 0;
                        for (String str : UsersList) {
                            String[] arrSplit1 = str.split("\\|");
                            if (arrSplit1[2].equals(arrSplitUser[2])) UsersList.set(index, user);
                            index++;
                        }
                        admin.setListUsers(UsersList);
                        admin.writeUsersList();
                        admin.setVisible(false);
                        new Admin(admin.GetNameUser(), admin.GetSurnameUser(), admin.GetIDUser());
                    }
                    if (answer == 1) {
                        admin.setVisible(false);
                        new Admin(admin.GetNameUser(), admin.GetSurnameUser(), admin.GetIDUser());
                    }
                }
                else JOptionPane.showMessageDialog(admin, "Вы не можете изменить свои права");
            } else JOptionPane.showMessageDialog(admin, "Логин уже используется");
        } else JOptionPane.showMessageDialog(admin, "Ошибка в формате регистрации");
    }
}