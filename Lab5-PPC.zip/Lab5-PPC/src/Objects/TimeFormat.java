package Objects;

import java.io.Serializable;

public class TimeFormat implements Serializable {
    private int hours = 0;
    private int minutes = 0;

    public int DataHours() {
        return hours;
    }
    public int DataMinutes() {
        return minutes;
    }

    public void SetDifferenceTime(int h1, int h2, int m1, int m2) {
        int h = 0, m = 0;
        if(h1 < h2){
            h = h2 - h1;
            if(m1 <= m2) m = m2 - m1;
            else m = 60 - m1 + m2;
        }
        else if(h1 == h2 && m1 < m2){
            m = m2 - m1;
        }
        this.hours = h;
        this.minutes = m;
    }

    public boolean StringToTime(String str) {
        boolean test1 = true;
        boolean test2;
        boolean test3;
        if (str.length() != 5) test1 = false;
        String[] arrSplit = str.split(":");
        test2 = CheckingTimeFormat.CheckDigit(arrSplit);
        int[] timeArr = new int[2];
        if (test1 && test2) {
            for (int i = 0; i < 2; i++) {
                timeArr[i] = Integer.parseInt(arrSplit[i]);
            }
            test3 = CheckingTimeFormat.CheckTime(timeArr[0], timeArr[1]);
            if(test3) {
                hours = timeArr[0];
                minutes = timeArr[1];
                return true;
            }
            else return false;
        }
        else return false;
    }
    public String TimeToString(){
        String formatted = hours + ":" + minutes;
        StringBuilder strB = new StringBuilder(formatted);
        if(hours < 10) strB.insert(0, '0');
        if(minutes < 10) strB.insert(3, '0');
        formatted = strB.toString();
        return formatted;
    }
    public void NumberTime(int h, int m){
        hours+=h;
        minutes+=m;
        while(minutes > 60) {
            hours++;
            minutes-=60;
        }
        while(minutes < 0) {
            hours--;
            minutes+=60;
        }
    }
    public String NumberTimeToString(){
        return hours + "ч." + minutes + "м.";
    }
}

class CheckingTimeFormat {
    public static boolean CheckDigit(String[] time){
        boolean test = true;
        int count = 0;
        for (int i = 0; i < time.length; i++) {
            count++;
            char[] Array = time[i].toCharArray();
            for (int j = 0; j < Array.length; j++) {
                if (!Character.isDigit(Array[j])) {
                    test = false;
                }
            }
        }
        if (count != 2) test = false;
        return test;
    }
    public static boolean CheckTime(int h, int m){
        boolean test = true;
        if(h < 0 || h > 23) test = false;
        if(m < 0 || m > 59) test = false;
        return test;
    }
}