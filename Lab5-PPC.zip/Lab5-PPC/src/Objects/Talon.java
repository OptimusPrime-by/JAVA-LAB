package Objects;
import Checking.Checking;

import java.io.Serializable;
import java.util.Locale;

public class Talon implements Serializable {
    private Doctor doctor;
    private TimeFormat TimeStart = new TimeFormat();
    private TimeFormat TimeLasting = new TimeFormat();
    private TimeFormat TimeEnd = new TimeFormat();
    private boolean Active = false;
    private String SurnamePatient;
    private String InitialsPatient;
    private int ID;
    private int IDUser;


    public String Patient(){
        return SurnamePatient + " " + InitialsPatient;
    }
    public Doctor getDoctor(){ return doctor;}
    public int getID() { return ID;}
    public int setIDUser() { return IDUser;}
    public void setIDUser(int id) { this.IDUser = id;}
    public String getTimeStart(){return TimeStart.TimeToString();}
    public String getTimeLastingH(){return String.valueOf(TimeLasting.DataHours());}
    public String getTimeLastingM(){return String.valueOf(TimeLasting.DataMinutes());}
    public boolean getActive(){return Active;}
    public String getSurnamePatient(){return SurnamePatient;}
    public String getInitialsPatient(){return InitialsPatient;}
    public String TalonViewDoctor(){
        return ID + " " + doctor.getSurname() + " " + TimeStart.TimeToString() + " " + doctor.getCabinet() + " каб.";
    }
    public TimeFormat getTimeStartFormat(){ return TimeStart;}
    public TimeFormat getTimeEndFormat(){ return TimeEnd;}
    @Override
    public String toString(){
        String ActiveTalon;
        if(Active) ActiveTalon = "Выдан" + "|" + Patient();
        else ActiveTalon = "Свободен" + "|" + "-";
        return ID + "|" + doctor.DoctorViewTalon() + "|" + TimeStart.TimeToString() + "|" +
                TimeLasting.NumberTimeToString() + "|" + ActiveTalon;
    }

    public boolean TalonInput(Doctor doctor, String timeStart, String timeLastingH, String timeLastingM, boolean active, String surname, String initials, int id){
        boolean test = true;
        this.doctor = doctor;
        if(!this.TimeStart.StringToTime(timeStart)) test = false;
        if(!Checking.RegTalonTimeStart(doctor.GetStartTime(), TimeStart)) test = false;
        if(!this.TimeLasting.StringToTime(FormatTimeNumber(timeLastingH) + ":" + FormatTimeNumber(timeLastingM))) test = false;
        if(test) {
            TimeFormat timeBuf = new TimeFormat();
            timeBuf.StringToTime(timeStart);
            timeBuf.NumberTime(TimeLasting.DataHours(), TimeLasting.DataMinutes());
            if(!Checking.RegTalonTimeStart(timeBuf,doctor.GetEndTime())) test = false;
        }
        if(test){
            TimeEnd.StringToTime(timeStart);
            TimeEnd.NumberTime(TimeLasting.DataHours(), TimeLasting.DataMinutes());
        }
        this.Active = active;
        if(active) {
            if (Checking.CheckString(surname)) this.SurnamePatient = surname;
            else test = false;
            if (Checking.CheckInitials(initials)) this.InitialsPatient = initials;
            else test = false;
        }
        else {
            this.SurnamePatient = "-";
            this.InitialsPatient = "-";
        }
        this.ID = id;
        return test;
    }

    private String FormatTimeNumber(String str){
        char[] Array = str.toCharArray();
        if (Array.length == 0) return "00";
        else if (Array.length == 1) return ("0"+str);
        else return str;
    }
}
