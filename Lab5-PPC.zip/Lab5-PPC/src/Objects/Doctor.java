package Objects;

import Checking.Checking;

import java.io.IOException;
import java.util.Locale;


import java.io.Serializable;

public class Doctor implements Serializable {
    private String Speciality;
    private String Surname;
    private String Name;
    private String MiddleName;
    private boolean FlagSpeciality; //0 - широкая специальность, 1 - узкая специальность
    private String Locality; // Участок
    private int Cabinet;
    private TimeFormat ReceptionStartTime = new TimeFormat();
    private TimeFormat ReceptionEndTime = new TimeFormat();
    private TimeFormat ReceptionTime = new TimeFormat();
    private int NumberTalons = 0;
    private TimeFormat TotalTimeAllTalons = new TimeFormat();
    private int ID;

    public Doctor() {

    }

    public String getStringFlag() {
        if(FlagSpeciality) return "Узкая специальность";
        else return "Широкая специальность";
    }
    public int getID(){return ID;}
    public String getSpeciality(){return Speciality;}
    public String getSurname(){return Surname;}
    public String getName(){return Name;}
    public String getMiddleName(){return MiddleName;}
    public boolean getFlagSpeciality(){return FlagSpeciality;}
    public String getLocality(){return Locality;}
    public String getCabinet(){ return String.valueOf(Cabinet);}
    public String getReceptionStartTime(){return ReceptionStartTime.TimeToString();}
    public String getReceptionEndTime(){return ReceptionEndTime.TimeToString();}


    public String DoctorViewTalon(){
        return Surname + " " + Name.toUpperCase(Locale.ROOT).charAt(0) +
                ". " + MiddleName.toUpperCase(Locale.ROOT).charAt(0) + ". " + Speciality;
    }

    public TimeFormat GetStartTime() {return ReceptionStartTime;}
    public TimeFormat GetEndTime() {return ReceptionEndTime;}
    public TimeFormat GetAllTime() {return TotalTimeAllTalons;}

    @Override
    public String toString() {
        String Area;
        if (FlagSpeciality) Area = "Широкая специальность" + "|" + Locality;
        else Area = "Узкая специальность" + "|" + "-";
        return "    " + ID + "|" + Speciality + "|" +
                Surname + "|" + Name + "|" + MiddleName + "|" + Area + "|" +
                Cabinet + "|" + ReceptionStartTime.TimeToString() + "|" +
                ReceptionEndTime.TimeToString() + "|" + NumberTalons + "|" +
                TotalTimeAllTalons.NumberTimeToString();
    }

    public boolean DoctorInput(String speciality, String surname, String name, String middleName,
                  boolean flag, String locality, String cabinet,
                  String Start, String End, int id){
        boolean test = true;
        if(Checking.CheckString(speciality) && Checking.CheckString(name) && Checking.CheckString(surname) && Checking.CheckString(middleName)) {
            this.Speciality = speciality.toLowerCase();
            this.Surname = surname;
            this.Name = name;
            this.MiddleName = middleName;
        }
        else test = false;
        this.FlagSpeciality = flag;
        this.Locality = "-";
        if(flag) this.Locality = locality;

        try {
            this.Cabinet = Integer.parseInt(cabinet);
            if(flag) {int buf = Integer.parseInt(Locality);}
        }
        catch (NumberFormatException e){
            test = false;
        }
        if(!this.ReceptionStartTime.StringToTime(Start) ||
        !this.ReceptionEndTime.StringToTime(End)) test = false;
        this.ReceptionTime.SetDifferenceTime(ReceptionStartTime.DataHours(), ReceptionEndTime.DataHours(), ReceptionStartTime.DataMinutes(), ReceptionEndTime.DataMinutes());
        if(!CheckingRegisterALL.RegisterReceptionTime(ReceptionTime.DataHours(), ReceptionTime.DataMinutes())) test = false;
        this.ID = id;
        return test;
    }
    public void DeleteTalon(int hours, int minutes, boolean Active){
        if(!Active) NumberTalons--;
        TotalTimeAllTalons.NumberTime(-hours, -minutes);
    }

    public boolean ChangeTalon(int h1, int m1, int hBuf2, int mBuf2, boolean Active1, boolean Active2){
        boolean test = CheckingRegisterALL.RegisterTalonsTime(ReceptionTime.DataHours(), ReceptionTime.DataMinutes(), hBuf2, mBuf2, TotalTimeAllTalons.DataHours(), TotalTimeAllTalons.DataMinutes());
        TimeFormat t2 = new TimeFormat();
        t2.SetDifferenceTime(hBuf2, h1, mBuf2, m1);
        if(test){
            TotalTimeAllTalons.NumberTime(t2.DataHours(), t2.DataMinutes());
            if(Active1 && !Active2) NumberTalons++;
            if(!Active1 && Active2) NumberTalons--;
        }
        return test;
    }

    public boolean RegisterTalon(int hours, int minutes, boolean Active){
        boolean test = CheckingRegisterALL.RegisterTalonsTime(ReceptionTime.DataHours(), ReceptionTime.DataMinutes(), hours, minutes, TotalTimeAllTalons.DataHours(), TotalTimeAllTalons.DataMinutes());
        if(test) {
            if(!Active) NumberTalons++;
            TotalTimeAllTalons.NumberTime(hours, minutes);
        }
        return test;
    }
}

class CheckingRegisterALL{
    public static boolean RegisterTalonsTime(int h1, int m1, int h2, int m2, int h3, int m3){
        int minutes1 = m1;
        while(h1 > 0){
            minutes1+= 60;
            h1--;
        }
        int minutes2 = m2;
        while(h2 > 0){
            minutes2+= 60;
            h2--;
        }
        int minutes3 = m3;
        while(h3 > 0){
            minutes3+= 60;
            h3--;
        }
        minutes2+=minutes3;
        minutes1 = (minutes1*80)/100;
        return (minutes1 >= minutes2);
    }
    public static boolean RegisterReceptionTime(int h, int m){
        int minutes = m;
        while(h > 0){
            minutes+= 60;
            h--;
        }
        return (minutes >= 240);
    }
}
