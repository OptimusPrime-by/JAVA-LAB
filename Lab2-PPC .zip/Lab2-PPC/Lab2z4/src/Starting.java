public class Starting {
    public static void main(String[]args) {
        String countryName = args[0];
        String data;
        System.out.println(countryName);
        for(int i = 1; i < args.length; i++){
            data = args[i];
            Data.Record(countryName, data);
        }
        Data.Output();
    }
}
