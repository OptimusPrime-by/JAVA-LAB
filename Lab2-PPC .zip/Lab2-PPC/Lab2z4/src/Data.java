public class Data {
    private static String[] dates = new String[100];
    private static int n = 0;

    public static void Record(String country, String date) {
        String buf;
        if (country.equalsIgnoreCase("Russia")) {
            buf = Russia.Form(date);
            if (!buf.equals("-1")) {
                dates[n] = buf;
                n++;
            }
        }
        if (country.equalsIgnoreCase("Canada")) {
            buf = Canada.Form(date);
            if (!buf.equals("-1")) {
                dates[n] = buf;
                n++;
            }
        }
        if (country.equalsIgnoreCase("Denmark")) {
            buf = Denmark.Form(date);
            if (!buf.equals("-1")) {
                dates[n] = buf;
                n++;
            }
        }
    }
    public static void Output(){
        if(n != 0) {
            for(int i = 0; i < n; i++){
                System.out.println(dates[i]);
            }
        }
        else System.out.println("Name of country is not correct.");
    }
}
