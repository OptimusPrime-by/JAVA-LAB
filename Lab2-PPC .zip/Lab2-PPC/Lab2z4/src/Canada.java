public class Canada {
    public static String Form(String str){
        boolean test = true;
        if(str.length() == 10) {
            String[] arrSplit = str.split("-");
            int count = 0;
            boolean test1 = true;
            for(int i = 0; i < arrSplit.length; i++){
                count++;
                char[] Array = arrSplit[i].toCharArray();
                for(int j = 0; j < Array.length; j++){
                    if(!Character.isDigit(Array[j])){
                        test1 = false;
                    }
                }
            }
            if (count == 3 && test1){
                if (arrSplit[0].length() != 4 ) test = false;
                int data = Integer.parseInt(arrSplit[1]);
                if (arrSplit[1].length() != 2 || data > 12) test = false;
                data = Integer.parseInt(arrSplit[2]);
                if (arrSplit[2].length() != 2 || data > 31) test = false;
            }
            else test = false;
        }
        else test = false;

        if(test) return str;
        else return "-1";
    }
}
