public class Task2 {
    public static void main(String[] args) {
        String str = args[0];
        StringBuilder str1 = new StringBuilder(str);
        char[] Array = str.toCharArray();
        for(int i = 0; i < str1.length()-1; i++){
            if(Character.isDigit(Array[i]) && Character.isDigit(Array[i+1])) { // isDigit - true если символ - цифра
                int j = i;
                while(j < str1.length() && Character.isDigit(Array[j])){
                    j++;
                }
                str1.delete(i, j);
                str = str1.toString();
                Array = str.toCharArray();
                i--;
            }
        }
        System.out.println(str1);
    }
}
