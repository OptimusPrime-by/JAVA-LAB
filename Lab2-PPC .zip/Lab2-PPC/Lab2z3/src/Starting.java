import by.vsu.mf.ai.ssd.strings.*;
public class Starting {
    public static void main(String[]args) {
        Task3 task = new Task3();
        Manager.createWindow(task);
    }
}
