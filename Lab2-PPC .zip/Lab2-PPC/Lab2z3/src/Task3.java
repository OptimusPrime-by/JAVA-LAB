import by.vsu.mf.ai.ssd.strings.Job;


public class Task3 implements Job{

    public void perform(StringBuilder str1) {
        String str = str1.toString();
        char[] Array = str.toCharArray();
        for(int i = 0; i < str1.length()-1; i++){
            if(Character.isDigit(Array[i]) && Character.isDigit(Array[i+1])) { // isDigit - true если символ - цифра
                int j = i;
                while(j < str1.length() && Character.isDigit(Array[j])){
                    j++;
                }
                str1.delete(i, j);
                str = str1.toString();
                Array = str.toCharArray();
                i--;
            }
        }
    }
}
