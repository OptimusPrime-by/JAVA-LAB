public class Sorting {
    private int counter(String str, String word){
        int count = 0;
        for(int i = 0; i < str.length()-word.length(); i++){
            String word1 = str.substring(i, i+word.length());
            if(word1.equalsIgnoreCase(word)) count++;
        }
        return count;
    }
     public boolean compare(String s1, String s2, String s) {
        if(counter(s1, s) < counter(s2, s)) return true;
        else return false;
    }
}