import java.util.Scanner;
import java.util.Arrays;

public class StringSorter {
    public static void main(String[] args) {
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
        System.out.println("Input string S:");
        Scanner scan = new Scanner(System.in);
        String S = scan.nextLine();

        Sorting sorting = new Sorting();
        for (int i = 0; i < args.length; i++) {
            for (int j = (args.length - 1); j >= (i + 1); j--) {
                if (sorting.compare(args[j], args[j - 1], S)) {
                    String tmp = args[j];
                    args[j] = args[j - 1];
                    args[j - 1] = tmp; // Bubble sort
                }
            }
        }
        System.out.println("Sort 1:");
        for(int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }

        Arrays.sort(args, new StringComparator());
        System.out.println("Sort 2:");
        for(int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
    }
}