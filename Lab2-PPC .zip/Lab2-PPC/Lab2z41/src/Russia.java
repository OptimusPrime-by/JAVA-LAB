public class Russia { // передать в Data extends без static

    public int[] StringToDate(String str) {
        boolean test1;
        boolean test2;
        String[] arrSplit = str.split("\\.");
        test1 = Checking.CheckDigit(arrSplit);
        int[] date = new int[3];
        if (test1) {
            for (int i = 0; i < 3; i++) {
                date[i] = Integer.parseInt(arrSplit[i]);
            }
        }
        if(test1) {
            int yearNull = arrSplit[2].indexOf('0');
            if(yearNull == 0) test1 = false;
        }
        test2 = Checking.CheckDate(date[0], date[1], date[2]);

        for (int i = 0; i < 3; i++) {
            if (!test1 || !test2) date[i] = -1;
        }
        return date;
    }

    public String DateToString(int d, int m, int y){
        String str = "-1";
        if(d != -1) {
            str = d + "." + m + "." + y;
            StringBuilder strB = new StringBuilder(str);
            if (d < 10) strB.insert(0, '0');
            if (m < 10) strB.insert(3, '0');
            str = strB.toString();
        }
        return str;
    }
}
