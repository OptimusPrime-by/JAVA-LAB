public class Data {
    private int k = 0; // количество записанных дат
    private Date[] Dates; // массив объктов дата
    public void addArray(int n) { // количество данных дат
        Dates = new Date[n];
    }
    public void Record(String country, String date) {
        Date bufDate = new Date(); // объект дата
        bufDate.country = country;
        boolean flag = bufDate.Format(date);
        if (flag) {
            Dates[k] = bufDate;
            k++;
        }
    }

    public void Output() {
        if (k != 0) {
            for(int i = 0; i < k; i++) {
                Dates[i].Out();
            }
        } else System.out.println("Name of country is not correct.");
    }

    public void Chronology(){
        for(int i = 0; i < k; i++) {
            int dayDelete = Dates[i].DataDay();
            if (dayDelete == -1){
                Dates[i] = null;
                for(int j = i; j < k-1; j++){
                    Dates[j] = Dates[j+1];
                }
                i--;
                k--;
            }
        } // удаление не корректных дат

        for (int i = 0; i < k; i++) {
            for (int j = (k - 1); j >= (i + 1); j--) {
                if (Checking.CheckOrder(Dates[j].DataDay(), Dates[j-1].DataDay(),Dates[j].DataMonth(), Dates[j-1].DataMonth(), Dates[j].DataYear(), Dates[j-1].DataYear())) {
                    Date tmp = Dates[j];
                    Dates[j] = Dates[j - 1];
                    Dates[j - 1] = tmp; // Bubble sort
                }
            }
        }
    }

    public void Task4(){
        int minCount = k+1;
        int bufCount = 0;
        boolean flag = false;
        for(int i = 0; i < k-1; i++){
            if(Checking.OneDay(Dates[i].DataDay(), Dates[i+1].DataDay(),Dates[i].DataMonth(), Dates[i+1].DataMonth(), Dates[i].DataYear(), Dates[i+1].DataYear())) {
                bufCount++;
                flag = true;
            }
            else {
                if (flag && minCount > bufCount) {
                    minCount = bufCount;
                    flag = false;
                }
                bufCount = 0;
            }
        }
        if(minCount == k+1) minCount = 0;
        else minCount++;
        System.out.println("The minimum number of consecutive dates in chronological order, the difference between which is equal to one day: " + minCount); //Минимальное количество подряд идущих в хронологическом порядке дат, разница между которыми равна одному дню.
    }
}