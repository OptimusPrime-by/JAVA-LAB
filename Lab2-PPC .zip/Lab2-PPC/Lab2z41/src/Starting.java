public class Starting {
    public static void main(String[]args) {
        String countryName = args[0];
        String data;
        int N = args.length - 1;
        System.out.println(countryName);
        Data dates = new Data();
        dates.addArray(N);
        for(int i = 1; i < args.length; i++){
            data = args[i];
            dates.Record(countryName, data);
        }
        dates.Output();
        dates.Chronology();
        System.out.println("Chronological order:");
        dates.Output();
        dates.Task4();
    }
}
