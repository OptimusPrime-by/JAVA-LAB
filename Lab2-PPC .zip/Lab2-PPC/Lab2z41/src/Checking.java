public class Checking {
    public static boolean CheckDigit(String[] date){
        boolean test = true;
        int count = 0;
        for (int i = 0; i < date.length; i++) {
            count++;
            char[] Array = date[i].toCharArray();
            for (int j = 0; j < Array.length; j++) {
                if (!Character.isDigit(Array[j])) {
                    test = false;
                }
            }
        }
        if (count != 3) test = false;
        return test;
    }
    public static boolean CheckDate(int day, int month, int year){
        boolean test = true;
        if (year > 0 && year < 10000 && month > 0 && month < 13 && day > 0) {
            if (month == 4 || month == 6 || month == 9 || month == 11) {
                if(day > 30) test = false;
            }
            else if (month == 2) {
                if (year % 4 == 0 && year % 100 != 0) {
                    if(day > 28) test = false;
                }
                else if(day > 29) test = false;
            }
            else if(day > 31) test = false;

        }
        else test = false;

        return test;
    }
    public static boolean CheckOrder(int d1, int d2, int m1, int m2, int y1, int y2){
        boolean order = true;
        if(y1 > y2) order = false;
        else if(y1 == y2){
            if(m1 > m2) order = false;
            else if(m1 == m2){
                if(d1 > d2) order = false;
                else if (d1 == d2) order = false;
            }
        }
        return order;
    }
    public static boolean OneDay(int d1, int d2, int m1, int m2, int y1, int y2){
        boolean test = true;
        int max = 31;
        if(m1 == 4 || m1 == 6 || m1 == 9 || m1 == 11) max = 30;
        else if (m1 == 2){
            if(y1 % 4 == 0 && y1 % 100 != 0) max = 28;
            else max = 29;
        }
        if(y1 == y2){
            if(m1 == m2){
                if(d2 - d1 != 1) test = false;
            }
            else if(m2 - m1 != 1 || d1 != max || d2 != 1){
                test  = false;
            }
        }
        else if (m2 != 12 || m1 != 1 || d1 != max || d2 != 1) test = false;

        return test;
    }
}
