public class Date{
    public String country;
    private int day;
    private int month;
    private int year;

    public int DataDay(){
        return day;
    }
    public int DataMonth(){
        return month;
    }
    public int DataYear(){
        return year;
    }

    public boolean Format(String date){
        int[] buf = {-2,-2,-2};
        if (country.equalsIgnoreCase("Russia")) {
            Russia rus = new Russia();
            buf = rus.StringToDate(date);
        }
        if (country.equalsIgnoreCase("Canada")) {
            Canada can = new Canada();
            buf = can.StringToDate(date);
        }
        if (country.equalsIgnoreCase("Denmark")) {
            Denmark den = new Denmark();
            buf = den.StringToDate(date);
        }
        if(buf[0] != -2){
            day = buf[0];
            month = buf[1];
            year = buf[2];
            return true;
        }
        else return false;
    }

    public void Out(){
        String formatted = "";
        if (country.equalsIgnoreCase("Russia")) {
            Russia rus = new Russia();
            formatted = rus.DateToString(day, month, year);
        }
        if (country.equalsIgnoreCase("Canada")) {
            Canada can = new Canada();
            formatted = can.DateToString(day, month, year);
        }
        if (country.equalsIgnoreCase("Denmark")) {
            Denmark den = new Denmark();
            formatted = den.DateToString(day, month, year);
        }
        if(!formatted.equals("-1")) System.out.println(formatted);
        else System.out.println("Date is not correct.");
    }
}
